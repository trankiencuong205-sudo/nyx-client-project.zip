package dev.nyx.gui;

import dev.nyx.NyxClient;
import dev.nyx.core.settings.BlockSetSetting;
import dev.nyx.data.BlockList;
import dev.nyx.util.Draw;
import dev.nyx.util.Keys;
import dev.nyx.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Full block list with search, multi-select and a colour per block. Esc goes back to the ClickGUI.
 * Click a row to select / unselect it; click the colour square of a selected block to change its colour.
 */
public class BlockPickerScreen extends Screen {
    private static final int ROW_H = 24;
    private static final String[] FILTERS = {"All", "Selected", "Ores"};

    private final Screen parent;
    private final BlockSetSetting setting;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private String query = "";
    private int filter;
    private List<BlockList.Entry> filtered = new ArrayList<>();
    private String lastQuery = null;
    private int lastFilter = -1;
    private int lastVersion = -1;

    private float openAnim;
    private float scroll;
    private float scrollTarget;
    private long lastFrame = System.nanoTime();
    private float dt = 0.016f;
    private boolean prevL;
    private boolean prevR;
    private boolean clickL;
    private int mx, my;

    private String popupId;
    private int popupX, popupY;

    public BlockPickerScreen(Screen parent, BlockSetSetting setting) {
        super(Text.literal("Choose blocks"));
        this.parent = parent;
        this.setting = setting;
        sync();
    }

    private void sync() {
        prevL = Keys.mouseDown(0);
        prevR = Keys.mouseDown(1);
        for (int k = 32; k < prevKeys.length; k++) prevKeys[k] = Keys.down(k);
    }

    @Override
    protected void init() {
        sync();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    public void removed() {
        dev.nyx.Config.save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scrollTarget -= (float) vertical * 48f;
        return true;
    }

    private void pollKeys() {
        boolean shift = Keys.shift();
        for (int k = 32; k < prevKeys.length; k++) {
            boolean down = Keys.down(k);
            boolean edge = down && !prevKeys[k];
            prevKeys[k] = down;
            if (!edge || k == GLFW.GLFW_KEY_ESCAPE) continue;
            if (k == NyxClient.GUI_KEY) {
                NyxClient.suppressGuiKeyUntilReleased();
                MinecraftClient.getInstance().setScreen(null);
                return;
            }
            if (k == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
            } else {
                char ch = Keys.typed(k, shift);
                if (ch != 0 && query.length() < 30) query += Character.toLowerCase(ch);
            }
        }
    }

    private static float ease(float cur, float target, float dt, float speed) {
        float k = 1f - (float) Math.exp(-dt * speed);
        float v = cur + (target - cur) * k;
        return Math.abs(v - target) < 0.002f ? target : v;
    }

    private void refilter() {
        if (query.equals(lastQuery) && filter == lastFilter && setting.version() == lastVersion) return;
        lastQuery = query;
        lastFilter = filter;
        lastVersion = setting.version();
        String q = query.toLowerCase(Locale.ROOT).trim().replace(' ', '_');
        String q2 = query.toLowerCase(Locale.ROOT).trim();
        List<BlockList.Entry> out = new ArrayList<>();
        for (BlockList.Entry e : BlockList.all()) {
            if (filter == 1 && !setting.has(e.id)) continue;
            if (filter == 2 && !BlockList.isOre(e.id)) continue;
            if (!q2.isEmpty() && !e.search.contains(q2) && !e.id.contains(q)) continue;
            out.add(e);
        }
        filtered = out;
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private boolean button(DrawContext c, String label, int x1, int y1, int x2, int y2, boolean active) {
        boolean hover = popupId == null && in(mx, my, x1, y1, x2, y2);
        if (active || hover) Draw.glow(c, x1, y1, x2, y2, Theme.ACCENT, 2, hover ? 70 : 40);
        Draw.rounded(c, x1, y1, x2, y2, active ? Theme.ACCENT : (hover ? Theme.BORDER : Theme.PANEL));
        Draw.textCentered(c, label, (x1 + x2) / 2, y1 + (y2 - y1 - 8) / 2, Theme.TEXT);
        return hover && clickL;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        long now = System.nanoTime();
        dt = Math.min(0.05f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;
        openAnim = ease(openAnim, 1f, dt, 11f);

        mx = mouseX;
        my = mouseY;
        boolean l = Keys.mouseDown(0);
        boolean r = Keys.mouseDown(1);
        clickL = l && !prevL;
        prevL = l;
        prevR = r;
        pollKeys();
        refilter();

        c.fill(0, 0, sw, sh, Theme.alpha(0xFF02020A, (int) (190 * openAnim)));

        int w = Math.min(sw - 30, 620);
        int h = Math.min(sh - 30, 420);
        int x0 = (sw - w) / 2;
        int y0 = (sh - h) / 2 + (int) ((1f - openAnim) * 30);
        Draw.glow(c, x0, y0, x0 + w, y0 + h, Theme.ACCENT, 6, (int) (46 * openAnim));
        Draw.rounded(c, x0 - 1, y0 - 1, x0 + w + 1, y0 + h + 1, Theme.BORDER);
        Draw.rounded(c, x0, y0, x0 + w, y0 + h, Theme.BG);
        Draw.gradientH(c, x0, y0, x0 + w, y0 + 1, Theme.ACCENT, Theme.ACCENT_2);

        // header
        c.fill(x0 + 1, y0 + 1, x0 + w - 1, y0 + 28, Theme.PANEL);
        Draw.gradientText(c, "CHOOSE BLOCKS", x0 + 12, y0 + 10, Theme.ACCENT, Theme.ACCENT_2);
        String count = setting.size() + " selected";
        Draw.text(c, count, x0 + 12 + Draw.textWidth("CHOOSE BLOCKS") + 10, y0 + 10, Theme.TEXT_DIM);
        if (button(c, "Done", x0 + w - 70, y0 + 5, x0 + w - 10, y0 + 23, false)) {
            clickL = false;
            close();
            return;
        }
        Draw.gradientH(c, x0 + 1, y0 + 27, x0 + w - 1, y0 + 28, Theme.ACCENT, Theme.ACCENT_2);

        // toolbar
        int ty = y0 + 34;
        int sx1 = x0 + 10, sx2 = x0 + 200;
        Draw.glow(c, sx1, ty, sx2, ty + 18, Theme.ACCENT_2, 3, 55);
        Draw.rounded(c, sx1, ty, sx2, ty + 18, Theme.BORDER);
        boolean caret = (System.currentTimeMillis() / 450) % 2 == 0;
        if (query.isEmpty()) Draw.text(c, (caret ? "_" : " ") + " search block...", sx1 + 6, ty + 5, Theme.TEXT_DIM);
        else Draw.text(c, ClickGuiScreen.tail(query, sx2 - sx1 - 14) + (caret ? "_" : ""), sx1 + 6, ty + 5, Theme.TEXT);

        int fx = sx2 + 8;
        for (int i = 0; i < FILTERS.length; i++) {
            int bw = Draw.textWidth(FILTERS[i]) + 16;
            if (button(c, FILTERS[i], fx, ty, fx + bw, ty + 18, filter == i)) {
                filter = i;
                scrollTarget = 0;
                clickL = false;
            }
            fx += bw + 4;
        }
        fx += 6;
        int bw1 = Draw.textWidth("+ Ores") + 16;
        if (button(c, "+ Ores", fx, ty, fx + bw1, ty + 18, false)) {
            for (BlockList.Entry e : BlockList.all()) if (BlockList.isOre(e.id)) setting.add(e.id);
            NyxClient.requestSave();
            clickL = false;
        }
        fx += bw1 + 4;
        int bw2 = Draw.textWidth("Clear") + 16;
        if (button(c, "Clear", fx, ty, fx + bw2, ty + 18, false)) {
            setting.clear();
            NyxClient.requestSave();
            clickL = false;
        }

        // list
        int ly1 = ty + 26, ly2 = y0 + h - 22;
        int lx1 = x0 + 10, lx2 = x0 + w - 12;
        float total = filtered.size() * ROW_H;
        float maxScroll = Math.max(0f, total - (ly2 - ly1));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll = ease(scroll, scrollTarget, dt, 16f);

        c.enableScissor(lx1, ly1, lx2, ly2);
        int first = Math.max(0, (int) (scroll / ROW_H));
        int last = Math.min(filtered.size(), first + (ly2 - ly1) / ROW_H + 2);
        for (int i = first; i < last; i++) {
            BlockList.Entry e = filtered.get(i);
            int ry = ly1 + i * ROW_H - Math.round(scroll);
            drawRow(c, e, lx1, ry, lx2 - 6, ly1, ly2);
        }
        c.disableScissor();
        if (filtered.isEmpty()) {
            Draw.textCentered(c, "No block matches", (lx1 + lx2) / 2, ly1 + 30, Theme.TEXT_DIM);
        }
        if (maxScroll > 0) {
            int trackH = ly2 - ly1;
            int barH = Math.max(18, (int) (trackH * (trackH / total)));
            int barY = ly1 + (int) ((trackH - barH) * (scroll / maxScroll));
            c.fillGradient(lx2 - 2, barY, lx2, barY + barH, Theme.ACCENT, Theme.ACCENT_2);
        }

        // footer
        String foot = filtered.size() + " blocks shown   Click: select   Colour square: change colour   Esc: back";
        Draw.text(c, ClickGuiScreen.fit(foot, w - 24), x0 + 12, y0 + h - 15, Theme.TEXT_DIM);

        if (popupId != null) drawPopup(c, sw, sh);
    }

    private void drawRow(DrawContext c, BlockList.Entry e, int x1, int y, int x2, int clipTop, int clipBottom) {
        boolean selected = setting.has(e.id);
        boolean hover = popupId == null && in(mx, my, x1, Math.max(y, clipTop), x2, Math.min(y + ROW_H, clipBottom));
        int bg = selected ? 0xFF1E1438 : (hover ? Theme.ROW_HOVER : Theme.ROW);
        Draw.rounded(c, x1, y + 1, x2, y + ROW_H - 1, bg);
        if (selected) c.fillGradient(x1, y + 4, x1 + 2, y + ROW_H - 4, Theme.ACCENT, Theme.ACCENT_2);

        // checkbox
        Draw.outline(c, x1 + 8, y + 7, x1 + 18, y + 17, selected ? Theme.ACCENT_2 : Theme.BORDER);
        if (selected) c.fill(x1 + 10, y + 9, x1 + 16, y + 15, Theme.ACCENT_2);

        if (!e.icon.isEmpty()) c.drawItem(e.icon, x1 + 24, y + 4);
        Draw.text(c, e.name, x1 + 46, y + 4, selected ? Theme.TEXT : Theme.lerp(Theme.TEXT_DIM, Theme.TEXT, 0.6f));
        Draw.text(c, e.id, x1 + 46, y + 14, Theme.alpha(Theme.TEXT_DIM, 200));

        int sx1 = x2 - 30, sx2 = x2 - 10;
        boolean onSwatch = false;
        if (selected) {
            int col = setting.color(e.id);
            onSwatch = hover && in(mx, my, sx1, y + 4, sx2, y + ROW_H - 4);
            Draw.glow(c, sx1, y + 5, sx2, y + ROW_H - 5, col, 2, onSwatch ? 120 : 70);
            Draw.rounded(c, sx1, y + 5, sx2, y + ROW_H - 5, col);
        }
        if (hover && clickL) {
            if (onSwatch) {
                popupId = e.id;
                popupX = Math.max(10, sx1 - 120);
                popupY = Math.max(10, y + ROW_H);
            } else {
                setting.toggle(e.id);
                NyxClient.requestSave();
            }
            clickL = false;
        }
    }

    private static final int CELL = 18;
    private static final int COLS = 6;
    private static final int POP_W = COLS * CELL + 12;
    private static final int POP_H = 2 * CELL + 12 + 8 + 14;

    private void drawPopup(DrawContext c, int sw, int sh) {
        int px = Math.min(popupX, sw - POP_W - 6);
        int py = Math.min(popupY, sh - POP_H - 6);
        Draw.glow(c, px, py, px + POP_W, py + POP_H, Theme.ACCENT, 4, 80);
        Draw.rounded(c, px - 1, py - 1, px + POP_W + 1, py + POP_H + 1, Theme.BORDER);
        Draw.rounded(c, px, py, px + POP_W, py + POP_H, Theme.PANEL);

        boolean inside = in(mx, my, px, py, px + POP_W, py + POP_H);
        int[] pal = BlockSetSetting.PALETTE;
        for (int i = 0; i < pal.length; i++) {
            int cx = px + 6 + (i % COLS) * CELL;
            int cy = py + 6 + (i / COLS) * CELL;
            boolean hv = in(mx, my, cx, cy, cx + CELL - 2, cy + CELL - 2);
            Draw.rounded(c, cx, cy, cx + CELL - 2, cy + CELL - 2, pal[i]);
            if (hv) Draw.outline(c, cx - 1, cy - 1, cx + CELL - 1, cy + CELL - 1, Theme.TEXT);
            if (hv && clickL) {
                setting.setColor(popupId, pal[i]);
                NyxClient.requestSave();
                popupId = null;
                clickL = false;
                return;
            }
        }
        // hue bar
        int hx1 = px + 6, hx2 = px + POP_W - 6, hy1 = py + 6 + 2 * CELL + 6, hy2 = hy1 + 12;
        int n = hx2 - hx1;
        for (int i = 0; i < n; i++) {
            c.fill(hx1 + i, hy1, hx1 + i + 1, hy2, hsv(i / (float) n));
        }
        Draw.outline(c, hx1 - 1, hy1 - 1, hx2 + 1, hy2 + 1, Theme.BORDER);
        if (in(mx, my, hx1, hy1, hx2, hy2) && clickL) {
            float hue = (mx - hx1) / (float) n;
            setting.setColor(popupId, hsv(hue));
            NyxClient.requestSave();
            popupId = null;
            clickL = false;
            return;
        }
        Draw.text(c, "preset or hue", px + 6, hy2 + 4, Theme.TEXT_DIM);
        if (clickL && !inside) {
            popupId = null;
            clickL = false;
        }
    }

    private static int hsv(float h) {
        h = Math.max(0f, Math.min(0.999f, h)) * 6f;
        int i = (int) h;
        float f = h - i;
        float s = 0.85f, v = 1f;
        float p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}

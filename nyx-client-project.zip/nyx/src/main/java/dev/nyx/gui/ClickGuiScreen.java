package dev.nyx.gui;

import dev.nyx.NyxClient;
import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.ModuleManager;
import dev.nyx.core.settings.ActionSetting;
import dev.nyx.core.settings.BlockSetSetting;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.ModeSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.core.settings.Setting;
import dev.nyx.core.settings.StringSetting;
import dev.nyx.util.Draw;
import dev.nyx.util.Keys;
import dev.nyx.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The ClickGUI: dark glass panel with neon purple/blue accents. Drawn in immediate mode; mouse and keyboard are read
 * straight from GLFW (see {@link Keys}) so it does not depend on Minecraft's input event signatures.
 *
 * Type to search modules. Left click a module: toggle. Right click (or the arrow): settings. Click the key box:
 * bind a key (Delete clears). Right Shift closes the menu.
 */
public class ClickGuiScreen extends Screen {
    private static final int ROW_H = 30;
    private static final int SET_H = 22;
    private static final int SIDEBAR_W = 108;
    private static final int HEADER_H = 30;
    private static final int FOOTER_H = 18;

    private static Category lastCategory = Category.COMBAT;
    private static final Map<Module, Boolean> EXPANDED = new HashMap<>();

    private final Map<Module, Float> expandAnim = new HashMap<>();
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private float openAnim;
    private float scroll;
    private float scrollTarget;
    private boolean prevL;
    private boolean prevR;
    private long lastFrame = System.nanoTime();
    private float dt = 0.016f;

    private String query = "";
    private boolean searchFocused = true;
    private Module binding;
    private StringSetting editing;
    private NumSetting dragging;
    private Screen pendingScreen;

    // per-frame state
    private boolean clickL;
    private boolean clickR;
    private boolean heldL;
    private int mx;
    private int my;
    private int cx1, cy1, cx2, cy2;
    private String hoverDesc = "";
    private float contentHeight;

    public ClickGuiScreen() {
        super(Text.literal("Nyx"));
        syncInput();
    }

    private void syncInput() {
        prevL = Keys.mouseDown(0);
        prevR = Keys.mouseDown(1);
        for (int k = 32; k < prevKeys.length; k++) prevKeys[k] = Keys.down(k);
    }

    // ------------------------------------------------------------------ Screen hooks

    @Override
    protected void init() {
        syncInput();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scrollTarget -= (float) vertical * 32f;
        return true;
    }

    @Override
    public void removed() {
        dev.nyx.Config.save();
    }

    @Override
    public void tick() {
        if (pendingScreen != null) {
            Screen next = pendingScreen;
            pendingScreen = null;
            MinecraftClient.getInstance().setScreen(next);
        }
    }

    // ------------------------------------------------------------------ input polling

    private void pollKeys() {
        boolean shift = Keys.shift();
        for (int k = 32; k < prevKeys.length; k++) {
            boolean down = Keys.down(k);
            boolean edge = down && !prevKeys[k];
            prevKeys[k] = down;
            if (edge) onKey(k, shift);
        }
    }

    private void onKey(int key, boolean shift) {
        if (key == GLFW.GLFW_KEY_ESCAPE) return; // vanilla closes the screen on Escape

        if (binding != null) {
            if (key == NyxClient.GUI_KEY) return;
            if (key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) binding.setKey(-1);
            else binding.setKey(key);
            binding = null;
            NyxClient.requestSave();
            return;
        }
        if (editing != null) {
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                editing = null;
            } else if (key == GLFW.GLFW_KEY_BACKSPACE) {
                String t = editing.get();
                if (!t.isEmpty()) editing.set(t.substring(0, t.length() - 1));
                NyxClient.requestSave();
            } else {
                char ch = Keys.typed(key, shift);
                if (ch != 0) {
                    editing.set(editing.get() + ch);
                    NyxClient.requestSave();
                }
            }
            return;
        }
        if (key == NyxClient.GUI_KEY) {
            NyxClient.suppressGuiKeyUntilReleased();
            MinecraftClient.getInstance().setScreen(null);
            return;
        }
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                scrollTarget = 0;
            } else {
                char ch = Keys.typed(key, shift);
                if (ch != 0 && query.length() < 24) {
                    query += Character.toLowerCase(ch);
                    scrollTarget = 0;
                }
            }
        }
    }

    // ------------------------------------------------------------------ rendering

    private static float ease(float cur, float target, float dt, float speed) {
        float k = 1f - (float) Math.exp(-dt * speed);
        float v = cur + (target - cur) * k;
        return Math.abs(v - target) < 0.002f ? target : v;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        long now = System.nanoTime();
        dt = Math.min(0.05f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;

        openAnim = ease(openAnim, 1f, dt, 11f);
        mx = mouseX;
        my = mouseY;
        boolean l = Keys.mouseDown(0);
        boolean r = Keys.mouseDown(1);
        clickL = l && !prevL;
        clickR = r && !prevR;
        heldL = l;
        prevL = l;
        prevR = r;
        if (!heldL) dragging = null;
        hoverDesc = "";
        pollKeys();

        c.fill(0, 0, sw, sh, Theme.alpha(0xFF02020A, (int) (170 * openAnim)));
        drawMotes(c, sw, sh, openAnim);

        int w = Math.min(sw - 30, 660);
        int h = Math.min(sh - 30, 420);
        int x0 = (sw - w) / 2;
        int y0 = (sh - h) / 2 + (int) ((1f - openAnim) * 30);

        Draw.glow(c, x0, y0, x0 + w, y0 + h, Theme.ACCENT, 6, (int) (46 * openAnim));
        Draw.rounded(c, x0 - 1, y0 - 1, x0 + w + 1, y0 + h + 1, Theme.BORDER);
        Draw.rounded(c, x0, y0, x0 + w, y0 + h, Theme.BG);
        drawBorder(c, x0, y0, w, h);

        drawHeader(c, x0, y0, w);
        drawSidebar(c, x0, y0, h);

        cx1 = x0 + SIDEBAR_W + 8;
        cy1 = y0 + HEADER_H + 6;
        cx2 = x0 + w - 8;
        cy2 = y0 + h - FOOTER_H - 4;
        drawModules(c);
        drawFooter(c, x0, y0, w, h);

        if (clickL) {
            if (editing != null) editing = null;
            if (binding != null) binding = null;
        }
    }

    private static double frac(double v) {
        return v - Math.floor(v);
    }

    private void drawMotes(DrawContext c, int sw, int sh, float a) {
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < 44; i++) {
            double fx = frac(Math.sin(i * 12.9898) * 43758.5453);
            double fy = frac(Math.sin(i * 78.233) * 12345.6789);
            double sp = 5 + fy * 14;
            double x = fx * sw + Math.sin(t * 0.5 + i) * 8;
            double y = ((fy * sh - t * sp) % sh + sh) % sh;
            int al = (int) (a * (30 + 70 * (0.5 + 0.5 * Math.sin(t * 1.6 + i))));
            int col = (i % 2 == 0) ? Theme.ACCENT : Theme.ACCENT_2;
            int sz = (i % 5 == 0) ? 2 : 1;
            c.fill((int) x, (int) y, (int) x + sz, (int) y + sz, Theme.alpha(col, al));
        }
    }

    /** Animated neon border: the colour flows along the top and bottom edges. */
    private void drawBorder(DrawContext c, int x0, int y0, int w, int h) {
        double t = System.currentTimeMillis() / 1000.0;
        int slices = 48;
        for (int i = 0; i < slices; i++) {
            int a = x0 + (w * i) / slices;
            int b = x0 + (w * (i + 1)) / slices;
            float f = (float) ((Math.sin(t * 1.2 + i * 0.22) + 1) / 2);
            int col = Theme.lerp(Theme.ACCENT, Theme.ACCENT_2, f);
            c.fill(a, y0, b, y0 + 1, col);
            float g = (float) ((Math.sin(t * 1.2 + i * 0.22 + 3) + 1) / 2);
            c.fill(a, y0 + h - 1, b, y0 + h, Theme.lerp(Theme.ACCENT, Theme.ACCENT_2, g));
        }
        c.fillGradient(x0, y0 + 1, x0 + 1, y0 + h - 1, Theme.ACCENT, Theme.ACCENT_2);
        c.fillGradient(x0 + w - 1, y0 + 1, x0 + w, y0 + h - 1, Theme.ACCENT_2, Theme.ACCENT);
    }

    private void drawHeader(DrawContext c, int x0, int y0, int w) {
        c.fill(x0 + 1, y0 + 1, x0 + w - 1, y0 + HEADER_H, Theme.PANEL);
        Draw.gradientText(c, "NYX", x0 + 12, y0 + 11, Theme.ACCENT, Theme.ACCENT_2);
        Draw.text(c, "client  1.21.1", x0 + 12 + Draw.textWidth("NYX") + 6, y0 + 11, Theme.TEXT_DIM);

        // search box
        int bw = 190;
        int bx2 = x0 + w - 12;
        int bx1 = bx2 - bw;
        int by1 = y0 + 7, by2 = y0 + HEADER_H - 7;
        boolean hover = in(mx, my, bx1, by1, bx2, by2);
        if (searchFocused) Draw.glow(c, bx1, by1, bx2, by2, Theme.ACCENT_2, 3, 60);
        Draw.rounded(c, bx1, by1, bx2, by2, searchFocused ? Theme.BORDER : (hover ? Theme.ROW_HOVER : Theme.ROW));
        boolean caret = searchFocused && (System.currentTimeMillis() / 450) % 2 == 0;
        if (query.isEmpty() && !searchFocused) {
            Draw.text(c, "Search modules...", bx1 + 8, by1 + 5, Theme.TEXT_DIM);
        } else if (query.isEmpty()) {
            Draw.text(c, (caret ? "_" : " ") + " type to search", bx1 + 8, by1 + 5, Theme.TEXT_DIM);
        } else {
            Draw.text(c, tail(query, bw - 36) + (caret ? "_" : ""), bx1 + 8, by1 + 5, Theme.TEXT);
            int xx1 = bx2 - 14;
            boolean hx = in(mx, my, xx1, by1, bx2, by2);
            Draw.text(c, "x", xx1 + 3, by1 + 5, hx ? Theme.BAD : Theme.TEXT_DIM);
            if (hx && clickL) {
                query = "";
                scrollTarget = 0;
                clickL = false;
            }
        }
        if (hover && clickL) {
            searchFocused = true;
            editing = null;
            binding = null;
            clickL = false;
        }
        Draw.gradientH(c, x0 + 1, y0 + HEADER_H - 1, x0 + w - 1, y0 + HEADER_H, Theme.ACCENT, Theme.ACCENT_2);
    }

    private void drawSidebar(DrawContext c, int x0, int y0, int h) {
        int top = y0 + HEADER_H;
        c.fill(x0 + 1, top, x0 + SIDEBAR_W, y0 + h - 1, Theme.PANEL_ALT);
        int y = top + 10;
        boolean searching = !query.isEmpty();
        for (Category cat : Category.values()) {
            int x1 = x0 + 7, x2 = x0 + SIDEBAR_W - 7;
            boolean selected = cat == lastCategory && !searching;
            boolean hover = mx >= x1 && mx < x2 && my >= y && my < y + 26;
            if (selected) {
                Draw.glow(c, x1, y, x2, y + 26, Theme.ACCENT, 3, 40);
                Draw.rounded(c, x1, y, x2, y + 26, Theme.ROW);
                c.fillGradient(x1, y + 4, x1 + 2, y + 22, Theme.ACCENT, Theme.ACCENT_2);
            } else if (hover) {
                Draw.rounded(c, x1, y, x2, y + 26, Theme.ROW_HOVER);
            }
            Draw.text(c, cat.label, x1 + 10, y + 9, selected ? Theme.TEXT : Theme.TEXT_DIM);
            int on = 0, total = 0;
            for (Module m : ModuleManager.get().inCategory(cat)) {
                total++;
                if (m.isEnabled()) on++;
            }
            String count = on + "/" + total;
            Draw.text(c, count, x2 - 6 - Draw.textWidth(count), y + 9, on > 0 ? Theme.ACCENT_2 : Theme.TEXT_DIM);
            if (hover) hoverDesc = total + " modules in " + cat.label;
            if (hover && clickL) {
                lastCategory = cat;
                query = "";
                scroll = 0;
                scrollTarget = 0;
                clickL = false;
            }
            y += 31;
        }
    }

    private void drawFooter(DrawContext c, int x0, int y0, int w, int h) {
        int y = y0 + h - FOOTER_H;
        c.fill(x0 + SIDEBAR_W, y, x0 + w - 1, y0 + h - 1, Theme.PANEL);
        String text = !hoverDesc.isEmpty() ? hoverDesc
                : "Left click: toggle   Right click: settings   Key box: bind (Delete clears)   Right Shift: close";
        Draw.text(c, fit(text, w - SIDEBAR_W - 20), x0 + SIDEBAR_W + 10, y + 5,
                hoverDesc.isEmpty() ? Theme.TEXT_DIM : Theme.TEXT);
    }

    private List<Module> visibleModules() {
        if (query.isEmpty()) return ModuleManager.get().inCategory(lastCategory);
        List<Module> out = new ArrayList<>();
        String q = query.toLowerCase(Locale.ROOT).trim();
        for (Module m : ModuleManager.get().all()) {
            String hay = (m.name + " " + m.category.label + " " + m.description).toLowerCase(Locale.ROOT);
            if (m.name.toLowerCase(Locale.ROOT).contains(q) || hay.contains(q)) out.add(m);
        }
        out.sort((a, b) -> Boolean.compare(!a.name.toLowerCase(Locale.ROOT).contains(q), !b.name.toLowerCase(Locale.ROOT).contains(q)));
        return out;
    }

    private void drawModules(DrawContext c) {
        List<Module> list = visibleModules();
        float maxScroll = Math.max(0f, contentHeight - (cy2 - cy1));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll = ease(scroll, scrollTarget, dt, 16f);

        c.enableScissor(cx1, cy1, cx2, cy2);
        int y = cy1 - Math.round(scroll);
        int start = y;
        if (list.isEmpty()) {
            Draw.textCentered(c, "No module matches '" + query + "'", (cx1 + cx2) / 2, cy1 + 30, Theme.TEXT_DIM);
        }
        for (Module m : list) {
            y += drawModule(c, m, cx1 + 2, y + 2, cx2 - 6);
        }
        contentHeight = y - start + 4;
        c.disableScissor();

        if (maxScroll > 0) {
            int trackH = cy2 - cy1;
            int barH = Math.max(18, (int) (trackH * (trackH / contentHeight)));
            int barY = cy1 + (int) ((trackH - barH) * (scroll / maxScroll));
            c.fillGradient(cx2 - 2, barY, cx2, barY + barH, Theme.ACCENT, Theme.ACCENT_2);
        }
    }

    private boolean inContent() {
        return mx >= cx1 && mx < cx2 && my >= cy1 && my < cy2;
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private int drawModule(DrawContext c, Module m, int x1, int y, int x2) {
        boolean expanded = EXPANDED.getOrDefault(m, false);
        float ea = ease(expandAnim.getOrDefault(m, 0f), expanded ? 1f : 0f, dt, 14f);
        expandAnim.put(m, ea);

        List<Setting<?>> visible = new ArrayList<>();
        for (Setting<?> s : m.settings) if (s.isVisible()) visible.add(s);
        int settingsH = visible.isEmpty() ? 0 : visible.size() * SET_H + 6;
        int extra = Math.round(settingsH * ea);
        int total = ROW_H + extra;

        m.anim = ease(m.anim, m.isEnabled() ? 1f : 0f, dt, 16f);

        boolean hoverRow = inContent() && in(mx, my, x1, y, x2, y + ROW_H);
        if (m.anim > 0.02f) Draw.glow(c, x1, y, x2, y + total, Theme.ACCENT, 3, (int) (34 * m.anim));
        int base = hoverRow ? Theme.ROW_HOVER : Theme.ROW;
        Draw.rounded(c, x1, y, x2, y + total, Theme.lerp(base, 0xFF221540, m.anim * 0.85f));
        c.fillGradient(x1, y + 5, x1 + 2, y + ROW_H - 5,
                Theme.lerp(Theme.BORDER, Theme.ACCENT, m.anim), Theme.lerp(Theme.BORDER, Theme.ACCENT_2, m.anim));

        Draw.text(c, m.name, x1 + 10, y + 6, Theme.lerp(Theme.TEXT_DIM, Theme.TEXT, m.anim));
        if (!query.isEmpty()) {
            Draw.text(c, m.category.label, x1 + 14 + Draw.textWidth(m.name), y + 6, Theme.alpha(Theme.ACCENT_2, 170));
        }

        int arrowX1 = x2 - 22, arrowX2 = x2 - 6;
        int swX2 = x2 - 28, swX1 = swX2 - 30;
        String keyText = binding == m ? "..." : Keys.name(m.getKey());
        int chipW = Math.max(40, Draw.textWidth(keyText) + 12);
        int chipX2 = swX1 - 8, chipX1 = chipX2 - chipW;

        int descMax = chipX1 - (x1 + 10) - 8;
        Draw.text(c, fit(m.description, descMax), x1 + 10, y + 17, Theme.TEXT_DIM);

        boolean hoverChip = inContent() && in(mx, my, chipX1, y + 7, chipX2, y + 23);
        Draw.rounded(c, chipX1, y + 7, chipX2, y + 23, hoverChip ? Theme.BORDER : Theme.PANEL);
        Draw.textCentered(c, keyText, (chipX1 + chipX2) / 2, y + 11, binding == m ? Theme.ACCENT_2 : Theme.TEXT_DIM);

        drawSwitch(c, swX1, y + 9, m.anim);

        boolean hoverArrow = inContent() && in(mx, my, arrowX1, y + 7, arrowX2, y + 23);
        if (!visible.isEmpty()) {
            Draw.textCentered(c, expanded ? "^" : "v", (arrowX1 + arrowX2) / 2, y + 11, hoverArrow ? Theme.TEXT : Theme.TEXT_DIM);
        }

        if (hoverRow) hoverDesc = m.description;

        if (inContent() && (clickL || clickR)) {
            if (hoverChip) {
                if (clickL) {
                    binding = m;
                    editing = null;
                } else {
                    m.setKey(-1);
                    NyxClient.requestSave();
                }
                clickL = clickR = false;
            } else if (hoverArrow && !visible.isEmpty()) {
                if (clickL) EXPANDED.put(m, !expanded);
                clickL = clickR = false;
            } else if (hoverRow) {
                if (clickL) {
                    m.toggle();
                } else if (!visible.isEmpty()) {
                    EXPANDED.put(m, !expanded);
                }
                clickL = clickR = false;
            }
        }

        if (ea > 0.02f && !visible.isEmpty()) {
            int clipTop = Math.max(y + ROW_H, cy1);
            int clipBottom = Math.min(y + total, cy2);
            if (clipBottom > clipTop) {
                c.enableScissor(x1, clipTop, x2, clipBottom);
                int sy = y + ROW_H + 3;
                boolean interactive = ea > 0.97f;
                for (Setting<?> s : visible) {
                    drawSetting(c, s, x1 + 10, sy, x2 - 10, interactive);
                    sy += SET_H;
                }
                c.disableScissor();
            }
        }
        return total + 4;
    }

    private void drawSwitch(DrawContext c, int x, int y, float anim) {
        int w = 30, h = 12;
        if (anim > 0.05f) Draw.glow(c, x, y, x + w, y + h, Theme.ACCENT_2, 2, (int) (60 * anim));
        Draw.rounded(c, x, y, x + w, y + h, Theme.lerp(Theme.BORDER, Theme.ACCENT, anim));
        if (anim > 0.02f) {
            Draw.gradientH(c, x + 1, y + 1, x + 1 + Math.max(1, (int) ((w - 2) * anim)), y + h - 1, Theme.ACCENT, Theme.ACCENT_2);
        }
        int knobX = x + 2 + Math.round(anim * (w - 4 - 8));
        Draw.rounded(c, knobX, y + 2, knobX + 8, y + h - 2, Theme.TEXT);
    }

    private void drawSetting(DrawContext c, Setting<?> s, int x1, int y, int x2, boolean interactive) {
        boolean hover = interactive && inContent() && in(mx, my, x1, y, x2, y + SET_H);
        if (hover) hoverDesc = s.name + ": " + s.description;

        if (s instanceof BoolSetting b) {
            Draw.text(c, b.name, x1, y + 7, Theme.TEXT);
            drawSwitch(c, x2 - 30, y + 5, b.on() ? 1f : 0f);
            if (hover && clickL) {
                b.toggle();
                NyxClient.requestSave();
                clickL = false;
            }
        } else if (s instanceof NumSetting n) {
            String value = format(n);
            Draw.text(c, n.name, x1, y + 2, Theme.TEXT);
            Draw.text(c, value, x2 - Draw.textWidth(value), y + 2, Theme.ACCENT_2);
            int by1 = y + 14, by2 = y + 18;
            Draw.rounded(c, x1, by1, x2, by2, Theme.PANEL);
            double t = (n.num() - n.min) / (n.max - n.min);
            int fillX = x1 + (int) Math.round((x2 - x1) * Math.max(0, Math.min(1, t)));
            if (fillX > x1) Draw.gradientH(c, x1, by1, fillX, by2, Theme.ACCENT, Theme.ACCENT_2);
            Draw.glow(c, fillX - 2, by1 - 2, fillX + 2, by2 + 2, Theme.ACCENT_2, 2, 70);
            Draw.rounded(c, fillX - 2, by1 - 2, fillX + 2, by2 + 2, Theme.TEXT);
            boolean hoverBar = interactive && inContent() && in(mx, my, x1 - 2, y + 10, x2 + 2, y + SET_H);
            if (hoverBar && clickL) {
                dragging = n;
                clickL = false;
            }
            if (dragging == n && heldL) {
                double v = Math.max(0, Math.min(1, (mx - x1) / (double) (x2 - x1)));
                n.set(n.min + v * (n.max - n.min));
                NyxClient.requestSave();
            }
        } else if (s instanceof ModeSetting mode) {
            Draw.text(c, mode.name, x1, y + 7, Theme.TEXT);
            int cw = Draw.textWidth(mode.get()) + 14;
            int cx = x2 - cw;
            Draw.rounded(c, cx, y + 3, x2, y + SET_H - 3, hover ? Theme.BORDER : Theme.PANEL);
            Draw.textCentered(c, mode.get(), cx + cw / 2, y + 7, Theme.ACCENT_2);
            if (hover && (clickL || clickR)) {
                mode.cycle(clickL);
                NyxClient.requestSave();
                clickL = clickR = false;
            }
        } else if (s instanceof BlockSetSetting bs) {
            Draw.text(c, bs.name, x1, y + 7, Theme.TEXT);
            String label = "Choose (" + bs.size() + ")";
            int cw = Draw.textWidth(label) + 16;
            int cx = x2 - cw;
            boolean hb = interactive && inContent() && in(mx, my, cx, y + 2, x2, y + SET_H - 2);
            if (hb) Draw.glow(c, cx, y + 2, x2, y + SET_H - 2, Theme.ACCENT, 2, 70);
            Draw.rounded(c, cx, y + 2, x2, y + SET_H - 2, hb ? Theme.ACCENT : Theme.PANEL);
            Draw.textCentered(c, label, cx + cw / 2, y + 7, Theme.TEXT);
            if (hb && clickL) {
                pendingScreen = new BlockPickerScreen(this, bs);
                clickL = false;
            }
        } else if (s instanceof StringSetting str) {
            Draw.text(c, str.name, x1, y + 7, Theme.TEXT);
            int bx1 = x1 + 70;
            boolean active = editing == str;
            Draw.rounded(c, bx1, y + 3, x2, y + SET_H - 3, active ? Theme.BORDER : Theme.PANEL);
            String shown = tail(str.get(), x2 - bx1 - 10);
            boolean caret = active && (System.currentTimeMillis() / 450) % 2 == 0;
            Draw.text(c, shown + (caret ? "_" : ""), bx1 + 5, y + 7, active ? Theme.TEXT : Theme.TEXT_DIM);
            if (hover && clickL && in(mx, my, bx1, y + 3, x2, y + SET_H - 3)) {
                editing = str;
                searchFocused = false;
                binding = null;
                clickL = false;
            }
        } else if (s instanceof ActionSetting action) {
            Draw.rounded(c, x1, y + 2, x2, y + SET_H - 2, hover ? Theme.ACCENT : Theme.PANEL);
            Draw.textCentered(c, action.name, (x1 + x2) / 2, y + 7, Theme.TEXT);
            if (hover && clickL) {
                action.run();
                clickL = false;
            }
        }
    }

    // ------------------------------------------------------------------ text helpers

    private static String format(NumSetting n) {
        double v = n.num();
        if (n.step >= 1 && Math.abs(v - Math.rint(v)) < 1e-9) return String.valueOf((long) Math.rint(v));
        return String.format(Locale.ROOT, n.step < 0.1 ? "%.2f" : "%.1f", v);
    }

    static String fit(String s, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (Draw.textWidth(s) <= maxWidth) return s;
        while (s.length() > 1 && Draw.textWidth(s + "...") > maxWidth) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    static String tail(String s, int maxWidth) {
        while (s.length() > 1 && Draw.textWidth(s) > maxWidth) s = s.substring(1);
        return s;
    }
}

package dev.nyx.modules.combat;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.util.Draw;
import dev.nyx.util.HudLayout;
import dev.nyx.util.Notifier;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorAlert extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] NAMES = {"Helmet", "Chest", "Legs", "Boots"};

    private final NumSetting percent = add(new NumSetting("Warn below", "Durability percentage that triggers the warning", 15, 1, 50, 1));
    private final BoolSetting panel = add(new BoolSetting("Panel", "Show durability of your armor on the HUD", true));

    private final boolean[] warned = new boolean[4];
    private final int[] percents = new int[]{-1, -1, -1, -1};
    private int tick;

    public ArmorAlert() {
        super("ArmorAlert", "Warns you before your armor or elytra breaks and shows its durability.", Category.COMBAT);
    }

    @Override
    protected void onTick() {
        if (mc.player == null || tick++ % 10 != 0) return;
        for (int i = 0; i < 4; i++) {
            ItemStack s = mc.player.getEquippedStack(SLOTS[i]);
            if (s.isEmpty() || !s.isDamageable()) {
                percents[i] = -1;
                warned[i] = false;
                continue;
            }
            int max = Math.max(1, s.getMaxDamage());
            int left = Math.max(0, max - s.getDamage());
            int pct = Math.round(left * 100f / max);
            percents[i] = pct;
            if (pct <= percent.intValue()) {
                if (!warned[i]) {
                    warned[i] = true;
                    Notifier.warn(NAMES[i] + " durability low: " + pct + "%");
                }
            } else if (pct > percent.intValue() + 5) {
                warned[i] = false;
            }
        }
    }

    @Override
    protected void onHud(DrawContext c) {
        if (!panel.on()) return;
        boolean any = false;
        for (int p : percents) any |= p >= 0;
        if (!any) return;
        int h = 4 * 11 + 6;
        int y = HudLayout.allocLeft(h);
        c.fill(4, y, 104, y + h, Theme.mul(Theme.PANEL, 0.88f));
        c.fill(4, y, 6, y + h, Theme.ACCENT);
        for (int i = 0; i < 4; i++) {
            int ty = y + 3 + i * 11;
            Draw.text(c, NAMES[i], 10, ty, Theme.TEXT_DIM);
            if (percents[i] < 0) {
                Draw.text(c, "-", 70, ty, Theme.TEXT_DIM);
                continue;
            }
            float ratio = percents[i] / 100f;
            int color = Theme.lerp(Theme.BAD, Theme.OK, ratio);
            Draw.text(c, percents[i] + "%", 60, ty, color);
        }
    }
}

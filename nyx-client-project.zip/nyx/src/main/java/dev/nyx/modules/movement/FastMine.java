package dev.nyx.modules.movement;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.ModuleManager;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.util.Notifier;
import dev.nyx.util.ServerGuard;

/**
 * Client-side faster block breaking. The server still decides: if it puts mined blocks back (rollback), FastMine
 * says so and switches itself off instead of pretending to work. No packets are altered.
 */
public class FastMine extends Module {
    private final NumSetting speed = add(new NumSetting("Multiplier",
            "Breaking speed factor. Most vanilla servers accept about 1.4x; more usually gets blocks put back.",
            1.3, 1.0, 4.0, 0.05));
    private final BoolSetting noDelay = add(new BoolSetting("No delay",
            "Skips the short client-side pause between two blocks", true));
    private final BoolSetting autoStop = add(new BoolSetting("Stop on rejection",
            "Turn off when the server keeps putting mined blocks back", true));

    private static FastMine instance;

    public FastMine() {
        super("FastMine", "Mines faster on the client. Checks whether the server accepts it and stops if it does not.", Category.MOVEMENT);
        instance = this;
    }

    public static boolean isOn() {
        return instance != null && instance.isEnabled();
    }

    public static double multiplier() {
        return isOn() ? instance.speed.num() : 1.0;
    }

    public static boolean noDelay() {
        return isOn() && instance.noDelay.on();
    }

    @Override
    public String getInfo() {
        return String.format("x%.2f  ok %d / back %d", speed.num(), ServerGuard.accepted(), ServerGuard.rejected());
    }

    @Override
    protected void onEnable() {
        ServerGuard.resetBreakStats();
    }

    @Override
    protected void onTick() {
        if (autoStop.on() && ServerGuard.recentRollbacks(15_000) >= 3) {
            Notifier.warn("FastMine: the server keeps putting blocks back - it rejects x"
                    + String.format("%.2f", speed.num()) + ". Lower the multiplier.");
            ServerGuard.resetBreakStats();
            setEnabled(false, false);
            dev.nyx.NyxClient.requestSave();
        }
    }
}

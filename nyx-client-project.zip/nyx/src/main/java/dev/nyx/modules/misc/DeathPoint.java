package dev.nyx.modules.misc;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.data.WaypointManager;
import dev.nyx.util.Notifier;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.screen.DeathScreen;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class DeathPoint extends Module {
    private int lastX, lastY, lastZ;
    private boolean hasPos;
    private boolean wasDead;

    public DeathPoint() {
        super("DeathPoint", "Saves a waypoint and prints the coordinates in chat where you died.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        hasPos = false;
        wasDead = false;
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        boolean dead = mc.currentScreen instanceof DeathScreen;
        if (!dead && mc.player.getHealth() > 0) {
            lastX = (int) Math.floor(mc.player.getX());
            lastY = (int) Math.floor(mc.player.getY());
            lastZ = (int) Math.floor(mc.player.getZ());
            hasPos = true;
        } else if (dead && !wasDead && hasPos) {
            String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
            WaypointManager.get().add("Death " + time, lastX, lastY, lastZ, Theme.BAD);
            Notifier.warn("Death point saved");
            Notifier.chat("You died at " + lastX + " " + lastY + " " + lastZ + " (waypoint 'Death " + time + "' saved)");
        }
        wasDead = dead;
    }
}

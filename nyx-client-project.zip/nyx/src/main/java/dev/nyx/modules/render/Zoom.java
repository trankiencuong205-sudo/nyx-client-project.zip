package dev.nyx.modules.render;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;

public class Zoom extends Module {
    private static final int MIN_FOV = 30;

    private final NumSetting level = add(new NumSetting("Level", "How much the view is magnified", 4.0, 1.5, 8.0, 0.5));
    private final BoolSetting smooth = add(new BoolSetting("Smooth", "Animate the zoom in and out", true));
    private final BoolSetting sensitivity = add(new BoolSetting("Scale sensitivity", "Lower mouse sensitivity while zoomed", true));

    private int originalFov = 70;
    private double originalSensitivity = 0.5;
    private double current = 70;
    private boolean active;

    public Zoom() {
        super("Zoom", "Magnifies the view (limited by Minecraft's minimum FOV of 30).", Category.RENDER);
    }

    @Override
    public String getInfo() {
        return level.num() + "x";
    }

    @Override
    protected void onEnable() {
        originalFov = mc.options.getFov().getValue();
        originalSensitivity = mc.options.getMouseSensitivity().getValue();
        current = originalFov;
        active = true;
    }

    @Override
    protected void onDisable() {
        restore();
    }

    @Override
    protected void onTick() {
        if (!active) return;
        double target = Math.max(MIN_FOV, Math.min(originalFov, originalFov / level.num()));
        current = smooth.on() ? current + (target - current) * 0.35 : target;
        int fov = (int) Math.round(current);
        if (mc.options.getFov().getValue() != fov) {
            mc.options.getFov().setValue(fov);
        }
        if (sensitivity.on()) {
            double scale = Math.max(0.1, current / originalFov);
            double s = Math.max(0.0, Math.min(1.0, originalSensitivity * scale));
            mc.options.getMouseSensitivity().setValue(s);
        }
    }

    private void restore() {
        if (!active) return;
        active = false;
        mc.options.getFov().setValue(originalFov);
        mc.options.getMouseSensitivity().setValue(originalSensitivity);
    }
}

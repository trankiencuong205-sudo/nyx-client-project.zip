package dev.nyx.modules.world;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.util.Draw;
import dev.nyx.util.HudLayout;
import dev.nyx.util.Projection;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.DrawContext;

public class ChunkBorders extends Module {
    private final NumSetting radius = add(new NumSetting("Radius", "Extra chunks drawn around your chunk", 1, 0, 3, 1));
    private final NumSetting height = add(new NumSetting("Height", "Blocks above and below you", 32, 8, 128, 8));
    private final BoolSetting rings = add(new BoolSetting("Section rings", "Horizontal lines at every 16 blocks of height", true));
    private final BoolSetting info = add(new BoolSetting("Info", "Chunk and region coordinates", true));

    public ChunkBorders() {
        super("ChunkBorders", "Shows chunk borders (16x16 columns and 16-high sections) around you.", Category.WORLD);
    }

    @Override
    protected void onHud(DrawContext c) {
        if (!Projection.isReady() || mc.player == null) return;
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        double py = mc.player.getY();
        double y0 = Math.floor(py - height.num());
        double y1 = Math.ceil(py + height.num());
        int r = radius.intValue();

        int dim = Theme.alpha(Theme.ACCENT, 150);
        int strong = Theme.ACCENT_2;

        for (int i = -r; i <= r + 1; i++) {
            for (int j = -r; j <= r + 1; j++) {
                boolean own = (i == 0 || i == 1) && (j == 0 || j == 1);
                double x = (pcx + i) * 16.0;
                double z = (pcz + j) * 16.0;
                Draw.worldLine(c, x, y0, z, x, y1, z, own ? strong : dim, own ? 2 : 1);
            }
        }

        if (rings.on()) {
            double x1 = pcx * 16.0, z1 = pcz * 16.0, x2 = x1 + 16.0, z2 = z1 + 16.0;
            int first = (int) Math.ceil(y0 / 16.0) * 16;
            for (int y = first; y <= y1; y += 16) {
                Draw.worldLine(c, x1, y, z1, x2, y, z1, dim, 1);
                Draw.worldLine(c, x2, y, z1, x2, y, z2, dim, 1);
                Draw.worldLine(c, x2, y, z2, x1, y, z2, dim, 1);
                Draw.worldLine(c, x1, y, z2, x1, y, z1, dim, 1);
            }
        }

        if (info.on()) {
            int bx = mc.player.getBlockPos().getX();
            int bz = mc.player.getBlockPos().getZ();
            String line1 = "Chunk " + pcx + ", " + pcz + "  (in chunk " + (bx & 15) + ", " + (bz & 15) + ")";
            String line2 = "Region r." + (pcx >> 5) + "." + (pcz >> 5) + "  |  Section Y " + (Math.floorDiv((int) Math.floor(py), 16));
            int w = Math.max(Draw.textWidth(line1), Draw.textWidth(line2)) + 12;
            int y = HudLayout.allocLeft(26);
            c.fill(4, y, 4 + w, y + 26, Theme.mul(Theme.PANEL, 0.88f));
            c.fill(4, y, 6, y + 26, strong);
            Draw.text(c, line1, 10, y + 3, Theme.TEXT);
            Draw.text(c, line2, 10, y + 14, Theme.TEXT_DIM);
        }
    }
}

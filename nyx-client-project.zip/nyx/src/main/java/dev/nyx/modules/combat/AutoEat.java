package dev.nyx.modules.combat;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

import java.util.Set;

public class AutoEat extends Module {
    private static final Set<String> NEVER = Set.of("rotten_flesh", "spider_eye", "pufferfish", "poisonous_potato",
            "chorus_fruit", "suspicious_stew", "raw_chicken");
    private static final Set<String> GOLDEN = Set.of("golden_apple", "enchanted_golden_apple");

    private final NumSetting threshold = add(new NumSetting("Hunger", "Start eating when food is at or below this (20 = full)", 14, 1, 19, 1));
    private final BoolSetting golden = add(new BoolSetting("Golden apples", "Allow golden apples as food", false));

    private boolean eating;
    private int previousSlot = -1;

    public AutoEat() {
        super("AutoEat", "Eats food from your hotbar when you get hungry, then returns to the item you were holding.", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        stop();
    }

    private boolean isFood(ItemStack s) {
        if (s.isEmpty() || !s.contains(DataComponentTypes.FOOD)) return false;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        if (NEVER.contains(id)) return false;
        return golden.on() || !GOLDEN.contains(id);
    }

    private void stop() {
        if (eating) {
            mc.options.useKey.setPressed(false);
            if (previousSlot >= 0 && mc.player != null) mc.player.getInventory().selectedSlot = previousSlot;
        }
        eating = false;
        previousSlot = -1;
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        int food = mc.player.getHungerManager().getFoodLevel();

        if (eating) {
            if (food >= 20 || mc.currentScreen != null || !isFood(mc.player.getMainHandStack())) {
                stop();
                return;
            }
            mc.options.useKey.setPressed(true);
            return;
        }

        if (food > threshold.intValue() || mc.currentScreen != null || mc.player.isUsingItem()) return;

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (isFood(mc.player.getInventory().getStack(i))) {
                slot = i;
                break;
            }
        }
        if (slot < 0) return;
        previousSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;
        eating = true;
    }
}

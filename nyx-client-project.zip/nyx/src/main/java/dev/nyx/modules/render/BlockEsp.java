package dev.nyx.modules.render;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BlockSetSetting;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.ModeSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.util.Draw;
import dev.nyx.util.Projection;
import dev.nyx.util.Theme;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Highlights the blocks you pick (any block in the game) in chunks the client has already received.
 * Scanning is incremental: at most ~2 ms per tick, nearest chunk first, section skipped quickly when its palette
 * does not contain a chosen block, and single block updates from the server are applied directly.
 */
public class BlockEsp extends Module {
    private static final long BUDGET_NANOS = 2_000_000L;
    private static final long RESCAN_TICKS = 1200;
    private static final int MAX_PER_CHUNK = 400;

    private final BlockSetSetting blocks = add(new BlockSetSetting("Blocks",
            "Pick any blocks, with a colour each", "diamond_ore", "deepslate_diamond_ore", "ancient_debris",
            "emerald_ore", "deepslate_emerald_ore"));
    private final ModeSetting style = add(new ModeSetting("Style", "Box: filled. Outline: 3D frame. Glow: filled with a soft halo",
            "Box", "Box", "Outline", "Glow"));
    private final NumSetting distance = add(new NumSetting("Distance", "Maximum distance in blocks", 64, 16, 128, 8));
    private final NumSetting maxBlocks = add(new NumSetting("Max blocks", "Upper limit of drawn blocks", 250, 50, 600, 25));
    private final NumSetting opacity = add(new NumSetting("Fill opacity", "Opacity of the box fill in percent", 28, 0, 80, 4));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", "Line from the bottom of the screen", false));
    private final BoolSetting names = add(new BoolSetting("Names", "Name and distance above nearby blocks", false));

    private static BlockEsp instance;

    private static final class Hit {
        final BlockPos pos;
        final int color;
        final Block block;

        Hit(BlockPos pos, int color, Block block) {
            this.pos = pos;
            this.color = color;
            this.block = block;
        }
    }

    private static final class ChunkResult {
        final List<Hit> hits = new ArrayList<>();
        long scannedAt;
    }

    private Map<Block, Integer> targets = new HashMap<>();
    private int version = -1;
    private final Map<Long, ChunkResult> cache = new HashMap<>();
    private List<Hit> visible = new ArrayList<>();
    private long tickCount;

    private WorldChunk scanChunk;
    private long scanKey;
    private int scanSection;
    private ChunkResult scanResult;

    public BlockEsp() {
        super("BlockESP", "Highlights chosen blocks (ores, chests, anything) in the chunks your client has loaded.", Category.RENDER);
        instance = this;
    }

    @Override
    public String getInfo() {
        return visible.isEmpty() ? "" : String.valueOf(visible.size());
    }

    @Override
    protected void onEnable() {
        reset();
    }

    @Override
    protected void onDisable() {
        cache.clear();
        visible = new ArrayList<>();
        scanChunk = null;
    }

    private void reset() {
        version = blocks.version();
        targets = blocks.resolve();
        cache.clear();
        visible = new ArrayList<>();
        scanChunk = null;
        tickCount = 0;
    }

    /** Called by the network mixin for every block change the server sends. */
    public static void onBlockChange(BlockPos pos, BlockState state) {
        BlockEsp e = instance;
        if (e == null || !e.isEnabled()) return;
        ChunkResult r = e.cache.get(chunkKey(pos.getX() >> 4, pos.getZ() >> 4));
        if (r == null) return;
        Iterator<Hit> it = r.hits.iterator();
        while (it.hasNext()) {
            if (it.next().pos.equals(pos)) {
                it.remove();
                break;
            }
        }
        Integer color = e.targets.get(state.getBlock());
        if (color != null && r.hits.size() < MAX_PER_CHUNK) r.hits.add(new Hit(pos.toImmutable(), color, state.getBlock()));
    }

    @Override
    protected void onTick() {
        tickCount++;
        if (version != blocks.version()) reset();
        if (targets.isEmpty() || mc.world == null || mc.player == null) return;

        double maxR = distance.num();
        int radiusChunks = (int) Math.ceil(maxR / 16.0);
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;

        cache.keySet().removeIf(k -> {
            int cx = (int) (k >> 32);
            int cz = (int) (long) k;
            return Math.abs(cx - pcx) > radiusChunks + 1 || Math.abs(cz - pcz) > radiusChunks + 1;
        });

        long deadline = System.nanoTime() + BUDGET_NANOS;
        while (System.nanoTime() < deadline) {
            if (scanChunk == null && !pickNext(pcx, pcz, radiusChunks)) break;
            if (scanStep(deadline)) {
                scanResult.scannedAt = tickCount;
                cache.put(scanKey, scanResult);
                scanChunk = null;
            }
        }
        if (tickCount % 10 == 0) rebuildVisible(maxR);
    }

    private boolean pickNext(int pcx, int pcz, int radiusChunks) {
        WorldChunk best = null;
        int bestDist = Integer.MAX_VALUE;
        int bx = 0, bz = 0;
        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                ChunkResult r = cache.get(chunkKey(cx, cz));
                if (r != null && tickCount - r.scannedAt < RESCAN_TICKS) continue;
                int d = dx * dx + dz * dz;
                if (d >= bestDist) continue;
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                best = chunk;
                bestDist = d;
                bx = cx;
                bz = cz;
            }
        }
        if (best == null) return false;
        scanChunk = best;
        scanKey = chunkKey(bx, bz);
        scanSection = 0;
        scanResult = new ChunkResult();
        return true;
    }

    private boolean scanStep(long deadline) {
        ChunkSection[] sections = scanChunk.getSectionArray();
        double py = mc.player.getY();
        double r = distance.num();
        int baseY = scanChunk.getBottomY();
        int cx = (int) (scanKey >> 32);
        int cz = (int) (long) scanKey;

        while (scanSection < sections.length) {
            if (System.nanoTime() >= deadline) return false;
            ChunkSection s = sections[scanSection];
            int y0 = baseY + scanSection * 16;
            scanSection++;
            if (s == null || s.isEmpty()) continue;
            if (y0 + 16 < py - r || y0 > py + r) continue;
            if (!s.hasAny(st -> targets.containsKey(st.getBlock()))) continue;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState state = s.getBlockState(x, y, z);
                        Integer color = targets.get(state.getBlock());
                        if (color == null) continue;
                        scanResult.hits.add(new Hit(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z), color, state.getBlock()));
                        if (scanResult.hits.size() >= MAX_PER_CHUNK) return true;
                    }
                }
            }
        }
        return true;
    }

    private void rebuildVisible(double maxR) {
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        double maxSq = maxR * maxR;
        List<Hit> all = new ArrayList<>();
        for (ChunkResult r : cache.values()) {
            for (Hit h : r.hits) {
                if (distSq(h, px, py, pz) <= maxSq) all.add(h);
            }
        }
        all.sort((a, b) -> Double.compare(distSq(a, px, py, pz), distSq(b, px, py, pz)));
        int limit = maxBlocks.intValue();
        visible = all.size() > limit ? new ArrayList<>(all.subList(0, limit)) : all;
    }

    private static double distSq(Hit h, double px, double py, double pz) {
        double dx = h.pos.getX() + 0.5 - px, dy = h.pos.getY() + 0.5 - py, dz = h.pos.getZ() + 0.5 - pz;
        return dx * dx + dy * dy + dz * dz;
    }

    private static long chunkKey(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    @Override
    protected void onHud(DrawContext c) {
        if (!Projection.isReady() || mc.player == null) return;
        int sw = Projection.width();
        int sh = Projection.height();
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        int fillAlpha = (int) (opacity.num() / 100.0 * 255.0);
        boolean outline = style.is("Outline");
        boolean glow = style.is("Glow");
        double pulse = 0.75 + 0.25 * Math.sin(System.currentTimeMillis() / 350.0);
        int drawn = 0;
        int wire = 0;

        for (Hit h : visible) {
            if (drawn >= 600) break;
            Box box = new Box(h.pos);
            int color = h.color;
            double[] b;
            if (outline) {
                b = Draw.bounds(box);
                if (b == null) continue;
                if (distSq(h, px, py, pz) < 24 * 24 && wire < 40) {
                    Draw.box3d(c, box, color);
                    wire++;
                } else {
                    Draw.box2d(c, box, color, 0);
                }
                if (fillAlpha > 0) {
                    c.fill((int) b[0], (int) b[1], (int) b[2], (int) b[3], Theme.alpha(color, fillAlpha / 2));
                }
            } else {
                b = Draw.box2d(c, box, color, Theme.alpha(color, fillAlpha));
                if (b == null) continue;
                if (glow) {
                    int x1 = (int) b[0], y1 = (int) b[1], x2 = (int) Math.ceil(b[2]), y2 = (int) Math.ceil(b[3]);
                    Draw.outline(c, x1 - 1, y1 - 1, x2 + 1, y2 + 1, Theme.alpha(color, (int) (150 * pulse)));
                    Draw.outline(c, x1 - 2, y1 - 2, x2 + 2, y2 + 2, Theme.alpha(color, (int) (80 * pulse)));
                    Draw.outline(c, x1 - 3, y1 - 3, x2 + 3, y2 + 3, Theme.alpha(color, (int) (35 * pulse)));
                }
            }
            drawn++;
            if (tracers.on()) {
                Draw.line(c, sw / 2.0, sh, (b[0] + b[2]) / 2.0, b[3], Theme.alpha(color, 190), 1);
            }
            if (names.on() && drawn <= 25) {
                String label = h.block.getName().getString() + " " + Math.round(Math.sqrt(distSq(h, px, py, pz))) + "m";
                Draw.textCentered(c, label, (int) ((b[0] + b[2]) / 2.0), (int) b[1] - 10, Theme.TEXT);
            }
        }
    }
}

package dev.nyx.modules.render;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BlockSetSetting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;

import java.util.HashSet;
import java.util.Set;

/**
 * Xray: only the chosen blocks are drawn, everything else is hidden. This only changes how chunk data the client
 * already has is displayed. It works with the vanilla renderer; renderer-replacement mods (e.g. Sodium) may ignore it.
 * Many servers forbid Xray, and servers with anti-xray send fake data that this cannot see through.
 */
public class Xray extends Module {
    private final BlockSetSetting blocks = add(new BlockSetSetting("Blocks", "Blocks that stay visible",
            "diamond_ore", "deepslate_diamond_ore", "ancient_debris", "emerald_ore", "deepslate_emerald_ore",
            "gold_ore", "deepslate_gold_ore", "iron_ore", "deepslate_iron_ore", "lapis_ore", "redstone_ore",
            "chest", "spawner"));

    private static Xray instance;
    private volatile Set<Block> visible = new HashSet<>();
    private int version = -1;

    public Xray() {
        super("Xray", "Shows only the blocks you choose (ores...) and hides the rest. Use with Fullbright.", Category.RENDER);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static boolean shouldDraw(BlockState state) {
        return instance == null || instance.visible.contains(state.getBlock());
    }

    private void rebuild() {
        version = blocks.version();
        visible = new HashSet<>(blocks.resolve().keySet());
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override
    protected void onEnable() {
        rebuild();
    }

    @Override
    protected void onDisable() {
        visible = new HashSet<>();
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override
    protected void onTick() {
        if (version != blocks.version()) rebuild();
    }

    @Override
    public String getInfo() {
        return String.valueOf(blocks.size());
    }
}

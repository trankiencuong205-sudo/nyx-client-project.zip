package dev.nyx.modules.movement;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;

public class Sprint extends Module {
    private final BoolSetting hungerCheck = add(new BoolSetting("Respect hunger", "Do not sprint when food is 6 or lower", true));

    public Sprint() {
        super("Sprint", "Sprints automatically while you walk forward (same rules as holding the sprint key).", Category.MOVEMENT);
    }

    @Override
    protected void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (!mc.options.forwardKey.isPressed()) return;
        if (mc.player.isSneaking() || mc.player.horizontalCollision || mc.player.isUsingItem()) return;
        if (hungerCheck.on() && mc.player.getHungerManager().getFoodLevel() <= 6) return;
        if (!mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }
    }
}

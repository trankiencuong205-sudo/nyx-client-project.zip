package dev.nyx.modules.misc;

import dev.nyx.Config;
import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.ModuleManager;
import dev.nyx.core.settings.ActionSetting;
import dev.nyx.util.Notifier;

/** Configuration buttons. The module itself does nothing when toggled; use the buttons in its settings. */
public class ConfigModule extends Module {
    public ConfigModule() {
        super("Config", "Save, reload or reset all settings. Settings are also saved automatically.", Category.MISC);
        add(new ActionSetting("Save now", "Write all settings to config/nyx/config.json", () -> {
            Config.save();
            Notifier.good("Config saved");
        }));
        add(new ActionSetting("Reload", "Read the settings back from the file", () -> {
            boolean ok = Config.load();
            Config.applyEnabledState();
            if (ok) Notifier.good("Config reloaded");
            else Notifier.warn("No config file found");
        }));
        add(new ActionSetting("Reset all", "Reset every setting and key bind to the defaults and turn all modules off", () -> {
            ModuleManager.get().disableAll();
            Config.resetAll();
            Notifier.warn("Everything reset to defaults");
        }));
    }

    @Override
    public String getInfo() {
        return "";
    }
}

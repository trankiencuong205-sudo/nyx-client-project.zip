package dev.nyx.modules.misc;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.ModeSetting;
import dev.nyx.core.settings.NumSetting;

public class AntiAfk extends Module {
    private final ModeSetting action = add(new ModeSetting("Action", "What to do to look active", "Look", "Look", "Jump", "Walk"));
    private final NumSetting interval = add(new NumSetting("Interval", "Seconds between actions", 30, 5, 120, 5));

    private long nextAt;
    private int walkTicks;
    private boolean jumpPressed;
    private int lookSign = 1;

    public AntiAfk() {
        super("AntiAFK", "Does a small harmless action every few seconds so the server does not kick you for idling.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        nextAt = System.currentTimeMillis() + (long) (interval.num() * 1000);
        walkTicks = 0;
        jumpPressed = false;
    }

    @Override
    protected void onDisable() {
        if (walkTicks > 0) mc.options.forwardKey.setPressed(false);
        if (jumpPressed) mc.options.jumpKey.setPressed(false);
        walkTicks = 0;
        jumpPressed = false;
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        if (jumpPressed) {
            mc.options.jumpKey.setPressed(false);
            jumpPressed = false;
        }
        if (walkTicks > 0) {
            walkTicks--;
            if (walkTicks == 0) mc.options.forwardKey.setPressed(false);
            return;
        }
        long now = System.currentTimeMillis();
        if (now < nextAt) return;
        nextAt = now + (long) (interval.num() * 1000);
        if (mc.currentScreen != null) return;

        if (action.is("Look")) {
            mc.player.setYaw(mc.player.getYaw() + 4.0f * lookSign);
            lookSign = -lookSign;
        } else if (action.is("Jump")) {
            if (mc.player.isOnGround()) {
                mc.options.jumpKey.setPressed(true);
                jumpPressed = true;
            }
        } else {
            mc.options.forwardKey.setPressed(true);
            walkTicks = 6;
        }
    }
}

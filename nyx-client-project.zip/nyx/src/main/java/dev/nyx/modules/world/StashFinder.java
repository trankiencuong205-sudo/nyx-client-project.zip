package dev.nyx.modules.world;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.ActionSetting;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.data.ChunkInfo;
import dev.nyx.data.ChunkScoring;
import dev.nyx.data.ChunkTracker;
import dev.nyx.data.WaypointManager;
import dev.nyx.util.Finding;
import dev.nyx.util.Notifier;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Finds clusters of storage blocks (chests, barrels, shulker boxes) across neighbouring chunks. */
public class StashFinder extends Module {
    private static final int COLOR = 0xFFF59E0B;

    private final NumSetting minContainers = add(new NumSetting("Min containers", "Containers needed in the cluster", 8, 2, 100, 1));
    private final NumSetting minShulkers = add(new NumSetting("Min shulkers", "Shulker boxes needed in the cluster", 0, 0, 50, 1));
    private final BoolSetting cluster = add(new BoolSetting("Cluster", "Add up the 3x3 chunks around each chunk (stashes span chunks)", true));
    private final NumSetting minDistance = add(new NumSetting("Min distance", "Hide results closer than this (blocks)", 0, 0, 5000, 50));
    private final NumSetting maxDistance = add(new NumSetting("Max distance", "Hide results further than this (0 = no limit)", 0, 0, 100000, 500));
    private final BoolSetting markers = add(new BoolSetting("Markers", "Marker with coordinates in the world", true));
    private final NumSetting rows = add(new NumSetting("List rows", "Results shown in the list (0 hides it)", 5, 0, 12, 1));

    private List<Finding> results = new ArrayList<>();
    private int tick;

    public StashFinder() {
        super("StashFinder", "Detects stashes: clusters of chests, barrels and shulker boxes, with coordinates and filters.", Category.WORLD);
        add(new ActionSetting("Add waypoints", "Save the current results as waypoints", this::addWaypoints));
        add(new ActionSetting("Print to chat", "Write the results with coordinates into the chat", this::printToChat));
    }

    @Override
    public String getInfo() {
        return results.isEmpty() ? "" : String.valueOf(results.size());
    }

    @Override
    protected void onEnable() {
        ChunkTracker.get().acquire(this);
        tick = 0;
    }

    @Override
    protected void onDisable() {
        ChunkTracker.get().release(this);
        results = new ArrayList<>();
    }

    private static final class Sum {
        int chests, barrels, shulkers;

        int total() {
            return chests + barrels + shulkers;
        }
    }

    @Override
    protected void onTick() {
        if (tick++ % 20 != 0) return;
        Map<Long, ChunkInfo> map = ChunkTracker.get().current();
        double px = mc.player.getX(), pz = mc.player.getZ();
        double min = minDistance.num(), max = maxDistance.num();
        boolean ring = cluster.on();

        Map<Long, Sum> sums = new HashMap<>();
        for (ChunkInfo c : new ArrayList<>(map.values())) {
            if (!c.scanned || c.storage() == 0) continue;
            Sum s = new Sum();
            int r = ring ? 1 : 0;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    ChunkInfo o = map.get(ChunkInfo.key(c.x + dx, c.z + dz));
                    if (o == null || !o.scanned) continue;
                    s.chests += o.chests + o.trappedChests;
                    s.barrels += o.barrels;
                    s.shulkers += o.shulkers;
                }
            }
            sums.put(ChunkInfo.key(c.x, c.z), s);
        }

        List<Finding> out = new ArrayList<>();
        for (Map.Entry<Long, Sum> e : sums.entrySet()) {
            Sum s = e.getValue();
            if (s.total() < minContainers.intValue() || s.shulkers < minShulkers.intValue()) continue;
            ChunkInfo c = map.get(e.getKey());
            if (c == null) continue;
            if (ring && !isLocalMaximum(c, s, sums)) continue;

            StringBuilder why = new StringBuilder();
            ChunkScoring.part(why, s.chests, "chest");
            ChunkScoring.part(why, s.barrels, "barrel");
            ChunkScoring.part(why, s.shulkers, "shulker");
            Finding f = new Finding(c, s.total(), why.toString());
            f.distance = Math.hypot(f.x - px, f.z - pz);
            if (f.distance < min) continue;
            if (max > 0 && f.distance > max) continue;
            out.add(f);
        }
        out.sort((a, b) -> Double.compare(a.distance, b.distance));
        results = out;
    }

    /** Keeps one result per cluster: the chunk whose 3x3 sum is the largest (ties broken by coordinates). */
    private boolean isLocalMaximum(ChunkInfo c, Sum mine, Map<Long, Sum> sums) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                Sum o = sums.get(ChunkInfo.key(c.x + dx, c.z + dz));
                if (o == null) continue;
                if (o.total() > mine.total()) return false;
                if (o.total() == mine.total() && (c.x + dx < c.x || (dx == 0 && c.z + dz < c.z))) return false;
            }
        }
        return true;
    }

    @Override
    protected void onHud(DrawContext c) {
        Finding.render(c, "Stash", results, COLOR, rows.intValue(), markers.on());
    }

    private void addWaypoints() {
        int n = 0;
        for (Finding f : results) {
            if (n >= 20) break;
            WaypointManager.get().add("Stash " + f.x + "," + f.z, f.x, f.y, f.z, COLOR);
            n++;
        }
        Notifier.good(n + " waypoints added");
    }

    private void printToChat() {
        if (results.isEmpty()) {
            Notifier.chat("StashFinder: nothing found yet");
            return;
        }
        int n = 0;
        for (Finding f : results) {
            if (n++ >= 15) break;
            Notifier.chat("Stash " + f.coords() + " (" + Math.round(f.distance) + "m): " + f.reason);
        }
    }
}

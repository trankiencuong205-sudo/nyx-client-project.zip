package dev.nyx.modules.misc;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.ModuleManager;
import dev.nyx.util.Notifier;

/** Turns every other module off in one press. Give it a key bind in the ClickGUI. */
public class Panic extends Module {
    public Panic() {
        super("Panic", "Disables every other module at once. Bind a key to it for instant use.", Category.MISC);
    }

    @Override
    protected void onTick() {
        ModuleManager.get().disableAll();
        setEnabled(false, false);
        Notifier.warn("All modules disabled");
    }
}

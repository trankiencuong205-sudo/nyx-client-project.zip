package dev.nyx.modules.world;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.core.settings.StringSetting;
import dev.nyx.util.Draw;
import dev.nyx.util.Notifier;
import dev.nyx.util.Projection;
import dev.nyx.util.Theme;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Highlights chosen blocks in the loaded chunks around you. Chunks are scanned in small time slices
 * (about 2 ms per tick), nearest first, and re-scanned every 30 seconds to pick up changes.
 */
public class Search extends Module {
    private static final int[] PALETTE = {0xFF22D3EE, 0xFFF472B6, 0xFFFBBF24, 0xFF34D399, 0xFFA78BFA, 0xFFFB923C, 0xFFF87171, 0xFF60A5FA};
    private static final long BUDGET_NANOS = 2_000_000L;
    private static final long RESCAN_TICKS = 600;
    private static final int MAX_PER_CHUNK = 300;

    private final StringSetting blocks = add(new StringSetting("Blocks",
            "Block names separated by commas. 'diamond_ore' is exact, '*ore' matches every id containing 'ore'.",
            "diamond_ore,deepslate_diamond_ore,ancient_debris", 160));
    private final NumSetting range = add(new NumSetting("Range", "Search radius in blocks", 48, 16, 128, 8));
    private final NumSetting maxResults = add(new NumSetting("Max results", "Upper limit of highlighted blocks", 300, 50, 1000, 50));
    private final BoolSetting fill = add(new BoolSetting("Fill", "Translucent fill inside the box", true));
    private final BoolSetting names = add(new BoolSetting("Names", "Block name above nearby results", false));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", "Line from the bottom of the screen", false));

    private static final class Hit {
        final BlockPos pos;
        final int color;
        final String name;

        Hit(BlockPos pos, int color, String name) {
            this.pos = pos;
            this.color = color;
            this.name = name;
        }
    }

    private static final class ChunkResult {
        final List<Hit> hits = new ArrayList<>();
        long scannedAt;
    }

    private final Set<Block> targets = new HashSet<>();
    private String parsedSpec = null;
    private final Map<Long, ChunkResult> cache = new HashMap<>();
    private List<Hit> visible = new ArrayList<>();
    private long tickCount;

    // scan in progress
    private WorldChunk scanChunk;
    private long scanKey;
    private int scanSection;
    private ChunkResult scanResult;

    public Search() {
        super("Search", "Highlights the blocks you choose (ores, chests, spawners...) in loaded chunks around you.", Category.WORLD);
    }

    @Override
    public String getInfo() {
        return visible.isEmpty() ? "" : String.valueOf(visible.size());
    }

    @Override
    protected void onEnable() {
        parsedSpec = null;
        cache.clear();
        scanChunk = null;
        tickCount = 0;
    }

    @Override
    protected void onDisable() {
        cache.clear();
        visible = new ArrayList<>();
        scanChunk = null;
    }

    /** Replaces the block list (used by the /nyx search command). */
    public void setBlocks(String spec) {
        blocks.set(spec);
        parsedSpec = null;
    }

    public String getBlocks() {
        return blocks.get();
    }

    private void parse() {
        parsedSpec = blocks.get();
        targets.clear();
        cache.clear();
        scanChunk = null;
        visible = new ArrayList<>();
        for (String raw : parsedSpec.split("[,; ]+")) {
            String token = raw.trim().toLowerCase();
            if (token.isEmpty()) continue;
            boolean contains = token.startsWith("*");
            if (contains) token = token.substring(1);
            if (token.isEmpty()) continue;

            if (!contains) {
                Identifier id = Identifier.tryParse(token.contains(":") ? token : "minecraft:" + token);
                if (id != null && Registries.BLOCK.containsId(id)) {
                    Block b = Registries.BLOCK.get(id);
                    if (!isAirId(id.getPath())) targets.add(b);
                    continue;
                }
            }
            // No exact block with that name: match every block whose id contains the text.
            for (Block b : Registries.BLOCK) {
                Identifier id = Registries.BLOCK.getId(b);
                String full = token.contains(":") ? id.toString() : id.getPath();
                if (full.contains(token) && !isAirId(id.getPath())) targets.add(b);
                if (targets.size() >= 600) break;
            }
        }
        if (targets.isEmpty()) {
            Notifier.warn("Search: no block matches '" + parsedSpec + "'");
        }
    }

    private static boolean isAirId(String path) {
        return path.equals("air") || path.equals("cave_air") || path.equals("void_air");
    }

    @Override
    protected void onTick() {
        tickCount++;
        if (parsedSpec == null || !parsedSpec.equals(blocks.get())) parse();
        if (targets.isEmpty() || mc.world == null || mc.player == null) return;

        double maxR = range.num();
        int radiusChunks = (int) Math.ceil(maxR / 16.0);
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;

        // forget chunks that left the range
        cache.keySet().removeIf(k -> {
            int cx = (int) (k >> 32);
            int cz = (int) (long) k;
            return Math.abs(cx - pcx) > radiusChunks + 1 || Math.abs(cz - pcz) > radiusChunks + 1;
        });

        long deadline = System.nanoTime() + BUDGET_NANOS;
        while (System.nanoTime() < deadline) {
            if (scanChunk == null && !pickNext(pcx, pcz, radiusChunks)) break;
            if (scanStep(deadline)) {
                scanResult.scannedAt = tickCount;
                cache.put(scanKey, scanResult);
                scanChunk = null;
            }
        }

        if (tickCount % 10 == 0) rebuildVisible(maxR);
    }

    /** Chooses the nearest chunk that has no result yet or whose result is stale. */
    private boolean pickNext(int pcx, int pcz, int radiusChunks) {
        WorldChunk best = null;
        int bestDist = Integer.MAX_VALUE;
        int bx = 0, bz = 0;
        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                ChunkResult r = cache.get(chunkKey(cx, cz));
                if (r != null && tickCount - r.scannedAt < RESCAN_TICKS) continue;
                int d = dx * dx + dz * dz;
                if (d >= bestDist) continue;
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                best = chunk;
                bestDist = d;
                bx = cx;
                bz = cz;
            }
        }
        if (best == null) return false;
        scanChunk = best;
        scanKey = chunkKey(bx, bz);
        scanSection = 0;
        scanResult = new ChunkResult();
        return true;
    }

    private boolean scanStep(long deadline) {
        ChunkSection[] sections = scanChunk.getSectionArray();
        double py = mc.player.getY();
        double r = range.num();
        int baseY = scanChunk.getBottomY();
        int cx = (int) (scanKey >> 32);
        int cz = (int) (long) scanKey;
        BlockPos.Mutable pos = new BlockPos.Mutable();

        while (scanSection < sections.length) {
            if (System.nanoTime() >= deadline) return false;
            ChunkSection s = sections[scanSection];
            int y0 = baseY + scanSection * 16;
            scanSection++;
            if (s == null || s.isEmpty()) continue;
            if (y0 + 16 < py - r || y0 > py + r) continue;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState state = s.getBlockState(x, y, z);
                        if (state.isAir()) continue;
                        Block b = state.getBlock();
                        if (!targets.contains(b)) continue;
                        String path = Registries.BLOCK.getId(b).getPath();
                        int color = PALETTE[Math.abs(path.hashCode()) % PALETTE.length];
                        scanResult.hits.add(new Hit(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z), color, path));
                        if (scanResult.hits.size() >= MAX_PER_CHUNK) return true;
                    }
                }
            }
        }
        return true;
    }

    private void rebuildVisible(double maxR) {
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        double maxSq = maxR * maxR;
        List<Hit> all = new ArrayList<>();
        for (ChunkResult r : cache.values()) {
            for (Hit h : r.hits) {
                double dx = h.pos.getX() + 0.5 - px, dy = h.pos.getY() + 0.5 - py, dz = h.pos.getZ() + 0.5 - pz;
                if (dx * dx + dy * dy + dz * dz <= maxSq) all.add(h);
            }
        }
        all.sort((a, b) -> Double.compare(distSq(a, px, py, pz), distSq(b, px, py, pz)));
        int limit = maxResults.intValue();
        visible = all.size() > limit ? new ArrayList<>(all.subList(0, limit)) : all;
    }

    private static double distSq(Hit h, double px, double py, double pz) {
        double dx = h.pos.getX() + 0.5 - px, dy = h.pos.getY() + 0.5 - py, dz = h.pos.getZ() + 0.5 - pz;
        return dx * dx + dy * dy + dz * dz;
    }

    private static long chunkKey(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    @Override
    protected void onHud(DrawContext c) {
        if (!Projection.isReady()) return;
        int sw = Projection.width();
        int sh = Projection.height();
        int drawn = 0;
        for (Hit h : visible) {
            if (drawn >= 300) break;
            int fillColor = fill.on() ? Theme.alpha(h.color, 55) : 0;
            double[] b = Draw.box2d(c, new Box(h.pos), h.color, fillColor);
            if (b == null) continue;
            drawn++;
            if (tracers.on()) {
                Draw.line(c, sw / 2.0, sh, (b[0] + b[2]) / 2.0, b[3], Theme.alpha(h.color, 190), 1);
            }
            if (names.on() && drawn <= 40) {
                Draw.textCentered(c, h.name, (int) ((b[0] + b[2]) / 2.0), (int) b[1] - 10, Theme.TEXT);
            }
        }
    }
}

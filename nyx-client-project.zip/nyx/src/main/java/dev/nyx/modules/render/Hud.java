package dev.nyx.modules.render;

import dev.nyx.NyxClient;
import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.ModuleManager;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.util.Draw;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Hud extends Module {
    private final BoolSetting watermark = add(new BoolSetting("Watermark", "Client name in the top-left corner", true));
    private final BoolSetting info = add(new BoolSetting("Info", "FPS, ping, speed and clock", true));
    private final BoolSetting coords = add(new BoolSetting("Coordinates", "Position, facing and Nether conversion", true));
    private final BoolSetting moduleList = add(new BoolSetting("Module list", "Enabled modules in the top-right corner", true));

    private double lastX, lastZ;
    private double speed;
    private boolean haveLast;

    public Hud() {
        super("HUD", "Shows coordinates, FPS, ping, speed and the list of enabled modules.", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        haveLast = false;
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        double x = mc.player.getX();
        double z = mc.player.getZ();
        if (haveLast) {
            double s = Math.hypot(x - lastX, z - lastZ) * 20.0;
            speed += (s - speed) * 0.3;
        }
        lastX = x;
        lastZ = z;
        haveLast = true;
    }

    @Override
    protected void onHud(DrawContext c) {
        if (mc.player == null || mc.world == null) return;
        int sw = mc.getWindow().getScaledWidth();
        int y = 4;

        if (watermark.on()) {
            String name = NyxClient.NAME;
            int w = Draw.textWidth(name) + 12;
            c.fill(4, y, 4 + w, y + 14, Theme.PANEL);
            c.fill(4, y, 6, y + 14, Theme.pulse(2.0));
            Draw.text(c, name, 10, y + 3, Theme.TEXT);
            y += 18;
        }

        if (info.on()) {
            List<String> lines = new ArrayList<>();
            lines.add("FPS " + mc.getCurrentFps());
            PlayerListEntry entry = mc.getNetworkHandler() == null ? null
                    : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) lines.add("Ping " + entry.getLatency() + " ms");
            lines.add(String.format("Speed %.1f b/s", speed));
            lines.add(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
            y = drawBlock(c, lines, 4, y);
        }

        if (coords.on()) {
            List<String> lines = new ArrayList<>();
            int x = (int) Math.floor(mc.player.getX());
            int py = (int) Math.floor(mc.player.getY());
            int z = (int) Math.floor(mc.player.getZ());
            lines.add("XYZ " + x + " " + py + " " + z + "  " + facing());
            String dim = mc.world.getRegistryKey().getValue().getPath();
            if (dim.equals("overworld")) {
                lines.add("Nether " + Math.floorDiv(x, 8) + " " + Math.floorDiv(z, 8));
            } else if (dim.equals("the_nether")) {
                lines.add("Overworld " + (x * 8) + " " + (z * 8));
            }
            drawBlock(c, lines, 4, y);
        }

        if (moduleList.on()) {
            drawModuleList(c, sw);
        }
    }

    private String facing() {
        float yaw = mc.player.getYaw();
        int d = (int) Math.floor(yaw * 4.0f / 360.0f + 0.5) & 3;
        switch (d) {
            case 0: return "S (+Z)";
            case 1: return "W (-X)";
            case 2: return "N (-Z)";
            default: return "E (+X)";
        }
    }

    private int drawBlock(DrawContext c, List<String> lines, int x, int y) {
        int w = 0;
        for (String s : lines) w = Math.max(w, Draw.textWidth(s));
        int h = lines.size() * 11 + 4;
        c.fill(x, y, x + w + 10, y + h, Theme.mul(Theme.PANEL, 0.85f));
        c.fill(x, y, x + 2, y + h, Theme.ACCENT);
        int ty = y + 3;
        for (String s : lines) {
            Draw.text(c, s, x + 6, ty, Theme.TEXT);
            ty += 11;
        }
        return y + h + 4;
    }

    private void drawModuleList(DrawContext c, int sw) {
        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.get().all()) {
            if (m.isEnabled() && m != this) active.add(m);
        }
        active.sort((a, b) -> Integer.compare(label(b).length(), label(a).length()));
        int y = 4;
        int i = 0;
        for (Module m : active) {
            String label = label(m);
            int w = Draw.textWidth(label) + 10;
            int x2 = sw - 4;
            int x1 = x2 - w;
            c.fill(x1, y, x2, y + 12, Theme.mul(Theme.PANEL, 0.85f));
            c.fill(x2 - 2, y, x2, y + 12, Theme.lerp(Theme.ACCENT, Theme.ACCENT_2, (i % 8) / 7f));
            Draw.text(c, m.name, x1 + 4, y + 2, Theme.TEXT);
            String extra = m.getInfo();
            if (!extra.isEmpty()) {
                Draw.text(c, extra, x1 + 4 + Draw.textWidth(m.name) + 4, y + 2, Theme.TEXT_DIM);
            }
            y += 12;
            i++;
        }
    }

    private String label(Module m) {
        String extra = m.getInfo();
        return extra.isEmpty() ? m.name : m.name + " " + extra;
    }
}

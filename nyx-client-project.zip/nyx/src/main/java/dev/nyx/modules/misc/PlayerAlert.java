package dev.nyx.modules.misc;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.util.Notifier;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class PlayerAlert extends Module {
    private final BoolSetting chat = add(new BoolSetting("Chat message", "Also write the alert (with coordinates) into the chat", true));
    private final BoolSetting leave = add(new BoolSetting("Leave alerts", "Tell me when a player leaves render distance", false));

    private final Map<UUID, String> known = new HashMap<>();
    private boolean primed;

    public PlayerAlert() {
        super("PlayerAlert", "Alerts you when another player comes into (or leaves) your render distance.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        known.clear();
        primed = false;
    }

    @Override
    protected void onTick() {
        if (mc.world == null || mc.player == null) return;
        Set<UUID> present = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            UUID id = p.getUuid();
            present.add(id);
            String name = p.getName().getString();
            if (!known.containsKey(id)) {
                known.put(id, name);
                if (primed) {
                    String where = (int) p.getX() + " " + (int) p.getY() + " " + (int) p.getZ();
                    Notifier.warn(name + " entered render distance");
                    if (chat.on()) {
                        Notifier.chat(name + " entered render distance at " + where + " (" + Math.round(mc.player.distanceTo(p)) + "m)");
                    }
                }
            }
        }
        known.entrySet().removeIf(e -> {
            if (present.contains(e.getKey())) return false;
            if (primed && leave.on()) Notifier.info(e.getValue() + " left render distance");
            return true;
        });
        primed = true;
    }
}

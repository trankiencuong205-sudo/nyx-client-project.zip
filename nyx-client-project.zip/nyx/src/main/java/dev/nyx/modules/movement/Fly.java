package dev.nyx.modules.movement;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.ModeSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.util.Notifier;
import dev.nyx.util.ServerGuard;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.util.math.Vec3d;

/**
 * Flight that respects the server.
 *  - Abilities: uses vanilla flying, only when the server granted it (creative, spectator or a /fly permission).
 *  - Velocity: also allowed in single player, where the local server permits it.
 * It refuses to turn on when the server has not allowed flying, and turns itself off when the server pulls the
 * permission or keeps correcting your position. There is no anti-kick or anti-cheat bypass.
 */
public class Fly extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Auto picks Abilities when the server allows it",
            "Auto", "Auto", "Abilities", "Velocity"));
    private final NumSetting speed = add(new NumSetting("Speed", "Horizontal speed multiplier", 1.0, 0.5, 5.0, 0.1));
    private final NumSetting vertical = add(new NumSetting("Vertical", "Up / down speed multiplier (Velocity mode)", 1.0, 0.5, 4.0, 0.1));

    private float oldFlySpeed;
    private boolean oldFlying;
    private boolean velocityMode;
    private boolean slowed;
    private int stuckTicks;
    private double lastX, lastZ;
    private Vec3d intended = Vec3d.ZERO;

    public Fly() {
        super("Fly", "Flight when the server allows it. Reports and stops if the server rejects it.", Category.MOVEMENT);
    }

    @Override
    public String getInfo() {
        return (velocityMode ? "Velocity " : "Abilities ") + String.format("x%.1f", speed.num());
    }

    private boolean singleplayer() {
        return mc.isInSingleplayer();
    }

    @Override
    protected String canEnable() {
        if (mc.player == null) return "not in a world";
        String denied = ServerGuard.flightDenied(mc);
        if (denied == null) return null;
        if (singleplayer() && !mode.is("Abilities")) return null;
        return denied + ". Fly did not start.";
    }

    @Override
    protected void onEnable() {
        ClientPlayerEntity p = mc.player;
        PlayerAbilities ab = p.getAbilities();
        oldFlySpeed = ab.getFlySpeed();
        oldFlying = ab.flying;
        boolean allowed = ServerGuard.flightDenied(mc) == null;
        velocityMode = mode.is("Velocity") || (mode.is("Auto") && !allowed);
        slowed = false;
        stuckTicks = 0;
        lastX = p.getX();
        lastZ = p.getZ();
        ServerGuard.clearTeleports();
        if (!velocityMode) ab.flying = true;
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        PlayerAbilities ab = p.getAbilities();
        ab.setFlySpeed(oldFlySpeed <= 0 ? 0.05f : oldFlySpeed);
        if (!velocityMode && !p.isCreative() && !p.isSpectator()) ab.flying = oldFlying;
    }

    @Override
    protected void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        boolean allowed = ServerGuard.flightDenied(mc) == null;

        if (!allowed && !(velocityMode && singleplayer())) {
            stop("the server no longer allows flying");
            return;
        }

        int bursts = ServerGuard.recentTeleports(3000);
        if (bursts >= 3) {
            if (speed.num() > 1.0 && !slowed) {
                slowed = true;
                ServerGuard.clearTeleports();
                Notifier.warn("Fly: the server is pulling you back at this speed. Using normal speed.");
            } else {
                stop("the server keeps correcting your position (rubber-band)");
                return;
            }
        }
        double factor = slowed ? 1.0 : speed.num();

        if (!velocityMode) {
            PlayerAbilities ab = p.getAbilities();
            ab.setFlySpeed(0.05f * (float) factor);
            if (!ab.flying && !p.isOnGround()) ab.flying = true;
            return;
        }

        // Velocity mode
        double yaw = Math.toRadians(p.getYaw());
        double fwd = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double side = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        double len = Math.sqrt(fwd * fwd + side * side);
        double vx = 0, vz = 0;
        if (len > 0) {
            fwd /= len;
            side /= len;
            double base = 0.5 * factor;
            vx = (-Math.sin(yaw) * fwd + Math.cos(yaw) * side) * base;
            vz = (Math.cos(yaw) * fwd + Math.sin(yaw) * side) * base;
        }
        double vy = 0;
        if (mc.options.jumpKey.isPressed()) vy += 0.4 * vertical.num();
        if (mc.options.sneakKey.isPressed()) vy -= 0.4 * vertical.num();
        intended = new Vec3d(vx, vy, vz);
        p.setVelocity(vx, vy, vz);

        // Honesty check: if we push but barely move, the server is holding us.
        double moved = Math.hypot(p.getX() - lastX, p.getZ() - lastZ);
        lastX = p.getX();
        lastZ = p.getZ();
        double want = Math.hypot(intended.x, intended.z);
        if (want > 0.2 && moved < want * 0.2 && !p.horizontalCollision) stuckTicks++;
        else stuckTicks = Math.max(0, stuckTicks - 1);
        if (stuckTicks >= 15) stop("the server is holding you in place");
    }

    private void stop(String reason) {
        Notifier.warn("Fly off: " + reason);
        setEnabled(false, false);
        dev.nyx.NyxClient.requestSave();
    }
}

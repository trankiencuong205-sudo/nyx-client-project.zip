package dev.nyx.modules.world;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.ActionSetting;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.ModeSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.data.ChunkInfo;
import dev.nyx.data.ChunkScoring;
import dev.nyx.data.ChunkTracker;
import dev.nyx.data.WaypointManager;
import dev.nyx.util.Finding;
import dev.nyx.util.Notifier;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Finds player bases from the block entities and blocks of every chunk the client has loaded. */
public class BaseFinder extends Module {
    private static final int COLOR = Theme.ACCENT_2;

    private final NumSetting minScore = add(new NumSetting("Min score", "Chunks below this score are hidden", 8, 2, 40, 1));
    private final NumSetting minDistance = add(new NumSetting("Min distance", "Hide results closer than this (blocks)", 0, 0, 5000, 50));
    private final NumSetting maxDistance = add(new NumSetting("Max distance", "Hide results further than this (0 = no limit)", 0, 0, 100000, 500));
    private final ModeSetting focus = add(new ModeSetting("Focus", "Only keep chunks that contain this kind of structure",
            "Any", "Any", "Beds", "Beacon/EnderChest", "Furnace/Hopper", "Storage"));
    private final BoolSetting markers = add(new BoolSetting("Markers", "Marker with coordinates in the world", true));
    private final NumSetting rows = add(new NumSetting("List rows", "Results shown in the list (0 hides it)", 5, 0, 12, 1));

    private List<Finding> results = new ArrayList<>();
    private int tick;

    public BaseFinder() {
        super("BaseFinder", "Detects bases from beds, furnaces, hoppers, beacons, containers and player-made blocks.", Category.WORLD);
        add(new ActionSetting("Add waypoints", "Save the current results as waypoints", this::addWaypoints));
        add(new ActionSetting("Print to chat", "Write the results with coordinates into the chat", this::printToChat));
        add(new ActionSetting("Clear results", "Forget bases found in this dimension", () -> {
            ChunkTracker.get().clearCurrentDimension();
            results = new ArrayList<>();
        }));
    }

    @Override
    public String getInfo() {
        return results.isEmpty() ? "" : String.valueOf(results.size());
    }

    @Override
    protected void onEnable() {
        ChunkTracker.get().acquire(this);
        tick = 0;
    }

    @Override
    protected void onDisable() {
        ChunkTracker.get().release(this);
        results = new ArrayList<>();
    }

    @Override
    protected void onTick() {
        if (tick++ % 20 != 0) return;
        double px = mc.player.getX(), pz = mc.player.getZ();
        double min = minDistance.num();
        double max = maxDistance.num();
        List<Finding> out = new ArrayList<>();
        for (ChunkInfo c : ChunkTracker.get().snapshot()) {
            if (!c.scanned) continue;
            double score = ChunkScoring.baseScore(c);
            if (score < minScore.num()) continue;
            if (!matchesFocus(c)) continue;
            Finding f = new Finding(c, score, ChunkScoring.baseReason(c));
            f.distance = Math.hypot(f.x - px, f.z - pz);
            if (f.distance < min) continue;
            if (max > 0 && f.distance > max) continue;
            out.add(f);
        }
        out.sort((a, b) -> Double.compare(a.distance, b.distance));
        results = out;
    }

    private boolean matchesFocus(ChunkInfo c) {
        if (focus.is("Beds")) return c.beds > 0;
        if (focus.is("Beacon/EnderChest")) return c.beacons > 0 || c.enderChests > 0;
        if (focus.is("Furnace/Hopper")) return c.furnaces > 0 || c.hoppers > 0;
        if (focus.is("Storage")) return c.storage() > 0;
        return true;
    }

    @Override
    protected void onHud(DrawContext c) {
        Finding.render(c, "Base", results, COLOR, rows.intValue(), markers.on());
    }

    private void addWaypoints() {
        int n = 0;
        for (Finding f : results) {
            if (n >= 20) break;
            WaypointManager.get().add("Base " + f.x + "," + f.z, f.x, f.y, f.z, COLOR);
            n++;
        }
        Notifier.good(n + " waypoints added");
    }

    private void printToChat() {
        if (results.isEmpty()) {
            Notifier.chat("BaseFinder: nothing found yet");
            return;
        }
        int n = 0;
        for (Finding f : results) {
            if (n++ >= 15) break;
            Notifier.chat("Base " + f.coords() + " (" + Math.round(f.distance) + "m): " + f.reason);
        }
    }
}

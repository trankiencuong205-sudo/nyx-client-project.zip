package dev.nyx.modules.movement;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.ModeSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.util.Notifier;
import dev.nyx.util.ServerGuard;
import net.minecraft.client.network.ClientPlayerEntity;

/** Faster walking. Switches itself off when the server keeps pulling you back; no anti-cheat bypass. */
public class Speed extends Module {
    private final NumSetting factor = add(new NumSetting("Multiplier", "Speed relative to normal walking/sprinting",
            1.2, 1.0, 3.0, 0.05));
    private final ModeSetting mode = add(new ModeSetting("Mode", "Ground: only on the ground. Always: also in the air",
            "Ground", "Ground", "Always"));

    public Speed() {
        super("Speed", "Moves faster. Stops and tells you if the server rejects the movement.", Category.MOVEMENT);
    }

    @Override
    public String getInfo() {
        return String.format("x%.2f", factor.num());
    }

    @Override
    protected void onEnable() {
        ServerGuard.clearTeleports();
    }

    @Override
    protected void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (ServerGuard.recentTeleports(3000) >= 3) {
            Notifier.warn("Speed off: the server keeps correcting your position at x"
                    + String.format("%.2f", factor.num()) + ". Lower the multiplier.");
            setEnabled(false, false);
            dev.nyx.NyxClient.requestSave();
            return;
        }
        if (p.getAbilities().flying || p.isFallFlying() || p.hasVehicle() || p.isClimbing()
                || p.isTouchingWater() || p.isInLava() || p.isSneaking()) return;
        if (!p.isOnGround() && mode.is("Ground")) return;

        double fwd = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double side = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        double len = Math.sqrt(fwd * fwd + side * side);
        if (len == 0) return;
        fwd /= len;
        side /= len;
        double yaw = Math.toRadians(p.getYaw());
        double base = p.isSprinting() ? 0.2806 : 0.2158;
        double target = base * factor.num();
        double vx = (-Math.sin(yaw) * fwd + Math.cos(yaw) * side) * target;
        double vz = (Math.cos(yaw) * fwd + Math.sin(yaw) * side) * target;
        p.setVelocity(vx, p.getVelocity().y, vz);
    }
}

package dev.nyx.modules.world;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.ActionSetting;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.data.WaypointManager;
import dev.nyx.data.WaypointManager.Waypoint;
import dev.nyx.util.Draw;
import dev.nyx.util.HudLayout;
import dev.nyx.util.Notifier;
import dev.nyx.util.Projection;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class Waypoints extends Module {
    private static final int[] PALETTE = {0xFF8B5CF6, 0xFF22D3EE, 0xFF34D399, 0xFFFBBF24, 0xFFF87171, 0xFFF472B6};

    private final BoolSetting labels = add(new BoolSetting("Labels", "Name and distance above each marker", true));
    private final BoolSetting list = add(new BoolSetting("List", "Nearest waypoints in a list with direction", true));
    private final NumSetting rows = add(new NumSetting("List rows", "Entries in the list", 4, 1, 10, 1));
    private final NumSetting maxDistance = add(new NumSetting("Max distance", "Hide waypoints further than this (0 = no limit)", 0, 0, 100000, 500));

    private List<Waypoint> cache = new ArrayList<>();
    private int tick;

    public Waypoints() {
        super("Waypoints", "Saved locations shown in the world. Use /nyx wp add <name> or the button below.", Category.WORLD);
        add(new ActionSetting("Add here", "Save a waypoint at your position", this::addHere));
        add(new ActionSetting("Clear dimension", "Delete all waypoints of this server and dimension", () -> {
            WaypointManager.get().clearHere();
            refresh();
            Notifier.info("Waypoints cleared");
        }));
    }

    @Override
    public String getInfo() {
        return cache.isEmpty() ? "" : String.valueOf(cache.size());
    }

    @Override
    protected void onEnable() {
        refresh();
        tick = 0;
    }

    private void refresh() {
        cache = WaypointManager.get().here();
    }

    public void addHere() {
        if (mc.player == null) return;
        int n = WaypointManager.get().here().size() + 1;
        addNamed("WP " + n);
    }

    public void addNamed(String name) {
        if (mc.player == null) return;
        int color = PALETTE[WaypointManager.get().everything().size() % PALETTE.length];
        WaypointManager.get().add(name, (int) Math.floor(mc.player.getX()), (int) Math.floor(mc.player.getY()),
                (int) Math.floor(mc.player.getZ()), color);
        refresh();
        Notifier.good("Waypoint '" + name + "' added");
    }

    @Override
    protected void onTick() {
        if (tick++ % 20 == 0) refresh();
    }

    @Override
    protected void onHud(DrawContext c) {
        if (mc.player == null || cache.isEmpty()) return;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        double max = maxDistance.num();
        double[] p = new double[3];
        List<Object[]> near = new ArrayList<>();

        for (Waypoint w : cache) {
            if (!w.visible) continue;
            double dx = w.x + 0.5 - px, dy = w.y + 0.5 - py, dz = w.z + 0.5 - pz;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (max > 0 && dist > max) continue;
            boolean onScreen = false;
            if (Projection.isReady() && Projection.toScreen(w.x + 0.5, w.y + 0.5, w.z + 0.5, p)) {
                int sx = (int) p[0], sy = (int) p[1];
                if (sx >= -10 && sy >= -10 && sx <= Projection.width() + 10 && sy <= Projection.height() + 10) {
                    onScreen = true;
                    c.fill(sx - 3, sy - 3, sx + 4, sy + 4, w.color);
                    Draw.outline(c, sx - 4, sy - 4, sx + 5, sy + 5, Theme.alpha(0xFF000000, 200));
                    c.fill(sx, sy + 5, sx + 1, sy + 40, Theme.alpha(w.color, 120));
                    if (labels.on()) {
                        Draw.textCentered(c, w.name, sx, sy - 18, Theme.TEXT);
                        Draw.textCentered(c, Math.round(dist) + "m", sx, sy - 9, Theme.TEXT_DIM);
                    }
                }
            }
            near.add(new Object[]{w, dist, onScreen});
        }

        if (list.on() && !near.isEmpty()) {
            near.sort((a, b) -> Double.compare((Double) a[1], (Double) b[1]));
            int shown = Math.min(rows.intValue(), near.size());
            int h = 14 + shown * 11 + 2;
            int y = HudLayout.allocLeft(h);
            int w = 120;
            String[] lines = new String[shown];
            for (int i = 0; i < shown; i++) {
                Waypoint wp = (Waypoint) near.get(i)[0];
                double dist = (Double) near.get(i)[1];
                boolean on = (Boolean) near.get(i)[2];
                lines[i] = wp.name + "  " + wp.x + " " + wp.y + " " + wp.z + "  " + Math.round(dist) + "m" + (on ? "" : "  " + bearing(wp));
                w = Math.max(w, Draw.textWidth(lines[i]) + 12);
            }
            c.fill(4, y, 4 + w, y + h, Theme.mul(Theme.PANEL, 0.88f));
            c.fill(4, y, 6, y + h, Theme.ACCENT);
            Draw.text(c, "Waypoints", 10, y + 3, Theme.ACCENT);
            for (int i = 0; i < shown; i++) {
                Draw.text(c, lines[i], 10, y + 14 + i * 11, Theme.TEXT);
            }
        }
    }

    /** ">>" if the waypoint is to the right of where the player looks, "<<" if it is to the left. */
    private String bearing(Waypoint w) {
        double dx = w.x + 0.5 - mc.player.getX();
        double dz = w.z + 0.5 - mc.player.getZ();
        double target = Math.toDegrees(Math.atan2(-dx, dz));
        double rel = target - mc.player.getYaw();
        rel = ((rel % 360) + 540) % 360 - 180;
        return rel > 0 ? ">>" : "<<";
    }
}

package dev.nyx.modules.movement;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;

public class AutoWalk extends Module {
    private final BoolSetting stopOnHurt = add(new BoolSetting("Stop when hurt", "Turn off when you take damage", true));

    private float lastHealth = -1;

    public AutoWalk() {
        super("AutoWalk", "Keeps the forward key held so you walk without touching the keyboard.", Category.MOVEMENT);
    }

    @Override
    protected void onEnable() {
        lastHealth = mc.player == null ? -1 : mc.player.getHealth();
    }

    @Override
    protected void onDisable() {
        mc.options.forwardKey.setPressed(false);
    }

    @Override
    protected void onTick() {
        if (mc.player == null) return;
        float hp = mc.player.getHealth();
        if (stopOnHurt.on() && lastHealth >= 0 && hp < lastHealth) {
            setEnabled(false);
            return;
        }
        lastHealth = hp;
        // Never hold the key while a screen (chat, inventory, GUI) is open.
        mc.options.forwardKey.setPressed(mc.currentScreen == null);
    }
}

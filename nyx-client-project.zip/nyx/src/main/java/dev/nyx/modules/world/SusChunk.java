package dev.nyx.modules.world;

import dev.nyx.core.Category;
import dev.nyx.core.Module;
import dev.nyx.core.settings.BoolSetting;
import dev.nyx.core.settings.NumSetting;
import dev.nyx.data.ChunkInfo;
import dev.nyx.data.ChunkScoring;
import dev.nyx.data.ChunkTracker;
import dev.nyx.util.ChunkMap;
import dev.nyx.util.ChunkOutline;
import dev.nyx.util.Finding;
import dev.nyx.util.Theme;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Flags chunks that show signs of player activity, using only data the client has received:
 * (1) old chunks surrounded by new ones (a travel trail), (2) many player-made blocks,
 * (3) utility blocks such as beds, furnaces, hoppers, and (4) clusters of containers.
 */
public class SusChunk extends Module {
    private static final int SUS_COLOR = 0xFFFBBF24;

    private final NumSetting minScore = add(new NumSetting("Min score", "Chunks below this score are hidden", 4, 1, 12, 1));
    private final NumSetting maxDistance = add(new NumSetting("Max distance", "Ignore chunks further than this many chunks", 40, 4, 128, 2));
    private final BoolSetting trails = add(new BoolSetting("Trails", "Old chunks inside new terrain", true));
    private final NumSetting trailNeighbours = add(new NumSetting("Trail neighbours", "New neighbours needed to count as a trail", 5, 3, 8, 1));
    private final BoolSetting blocks = add(new BoolSetting("Player-made blocks", "Concrete, redstone parts, stripped logs...", true));
    private final BoolSetting utility = add(new BoolSetting("Utility blocks", "Beds, furnaces, hoppers, signs, beacons...", true));
    private final BoolSetting storage = add(new BoolSetting("Containers", "Chests, barrels and shulker boxes", true));
    private final BoolSetting map = add(new BoolSetting("Map", "Top-down chunk map", true));
    private final BoolSetting outline = add(new BoolSetting("Outline", "Outline suspicious chunks on the ground", true));
    private final BoolSetting markers = add(new BoolSetting("Markers", "Marker with coordinates in the world", true));
    private final NumSetting rows = add(new NumSetting("List rows", "Results shown in the list (0 hides it)", 5, 0, 10, 1));

    private List<Finding> results = new ArrayList<>();
    private Map<Long, Double> scores = new HashMap<>();
    private int tick;

    public SusChunk() {
        super("SusChunk", "Flags suspicious chunks: travel trails, player-made blocks, utility blocks and container clusters.", Category.WORLD);
    }

    @Override
    public String getInfo() {
        return results.isEmpty() ? "" : String.valueOf(results.size());
    }

    @Override
    protected void onEnable() {
        ChunkTracker.get().acquire(this);
        tick = 0;
    }

    @Override
    protected void onDisable() {
        ChunkTracker.get().release(this);
        results = new ArrayList<>();
        scores = new HashMap<>();
    }

    @Override
    protected void onTick() {
        if (tick++ % 20 != 0) return;
        Map<Long, ChunkInfo> chunkMap = ChunkTracker.get().current();
        List<Finding> out = new ArrayList<>();
        Map<Long, Double> sc = new HashMap<>();

        double px = mc.player.getX(), pz = mc.player.getZ();
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        int maxD = maxDistance.intValue();

        for (ChunkInfo c : new ArrayList<>(chunkMap.values())) {
            if (!c.scanned) continue;
            if (Math.max(Math.abs(c.x - pcx), Math.abs(c.z - pcz)) > maxD) continue;
            double score = 0;
            StringBuilder why = new StringBuilder();

            if (trails.on() && c.status == ChunkInfo.Status.OLD
                    && ChunkScoring.newNeighbours(chunkMap, c) >= trailNeighbours.intValue()) {
                score += 3;
                add(why, "old chunk in new terrain");
            }
            if (blocks.on()) {
                if (c.artificial >= 30) {
                    score += 4;
                    add(why, c.artificial + " player-made blocks");
                } else if (c.artificial >= 6) {
                    score += 2;
                    add(why, c.artificial + " player-made blocks");
                }
            }
            if (utility.on()) {
                int u = c.beds + c.signs + c.furnaces + c.hoppers + c.dispensers + c.enderChests * 2
                        + c.beacons * 3 + c.enchantTables + c.brewingStands + c.crafters * 2;
                if (u >= 4) {
                    score += u >= 10 ? 4 : 2;
                    add(why, u + " utility blocks");
                }
            }
            if (storage.on() && c.storage() >= 3) {
                score += c.storage() >= 8 ? 4 : 2;
                add(why, c.storage() + " containers");
            }

            if (score >= minScore.num()) {
                Finding f = new Finding(c, score, why.toString());
                f.distance = Math.hypot(f.x - px, f.z - pz);
                out.add(f);
                sc.put(ChunkInfo.key(c.x, c.z), score);
            }
        }
        out.sort((a, b) -> Double.compare(a.distance, b.distance));
        results = out;
        scores = sc;
    }

    private static void add(StringBuilder sb, String s) {
        if (sb.length() > 0) sb.append(", ");
        sb.append(s);
    }

    private int colorOf(ChunkInfo c) {
        Double s = scores.get(ChunkInfo.key(c.x, c.z));
        if (s == null) return 0;
        return s >= 8 ? Theme.BAD : SUS_COLOR;
    }

    @Override
    protected void onHud(DrawContext c) {
        if (map.on()) {
            ChunkMap.draw(c, "SusChunk  " + results.size() + " flagged", 10, 4, this::colorOf);
        }
        if (outline.on() && !results.isEmpty()) {
            List<ChunkInfo> list = new ArrayList<>();
            for (Finding f : results) list.add(f.chunk);
            ChunkOutline.draw(c, list, this::colorOf, 6, 16);
        }
        if (rows.intValue() > 0 || markers.on()) {
            Finding.render(c, "Sus", results, SUS_COLOR, rows.intValue(), markers.on());
        }
    }
}

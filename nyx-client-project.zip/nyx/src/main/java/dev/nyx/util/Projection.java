package dev.nyx.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Projects world coordinates onto the GUI layer with our own camera maths, so overlays (ESP, waypoints,
 * chunk borders, search results) are drawn with the plain 2D DrawContext and do not depend on the
 * world-renderer internals, which change in almost every Minecraft release.
 */
public final class Projection {
    private Projection() {
    }

    private static final double NEAR = 0.05;

    private static double cx, cy, cz;
    private static double fx, fy, fz;
    private static double rx, ry, rz;
    private static double ux, uy, uz;
    private static double tanHalf = 1.0;
    private static double aspect = 1.0;
    private static int screenW = 1;
    private static int screenH = 1;
    private static boolean ready;

    /** Smoothed copy of vanilla's dynamic FOV multiplier (sprinting, speed effects, flying). */
    private static double fovMultiplier = 1.0;
    /** Wall-clock time of the last client tick, used to interpolate entity positions. */
    private static long lastTickNanos = System.nanoTime();

    public static void tick(MinecraftClient mc) {
        lastTickNanos = System.nanoTime();
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            fovMultiplier = 1.0;
            return;
        }
        double f = 1.0;
        if (p.getAbilities().flying) f *= 1.1;
        double walk = p.getAbilities().getWalkSpeed();
        if (walk > 0 && Double.isFinite(walk)) {
            f *= (p.getMovementSpeed() / walk + 1.0) / 2.0;
        }
        if (!Double.isFinite(f)) f = 1.0;
        double scale = mc.options.getFovEffectScale().getValue();
        double target = 1.0 + (f - 1.0) * scale;
        fovMultiplier += (target - fovMultiplier) * 0.5;
    }

    /** Fraction (0..1) of the current client tick that has elapsed. */
    public static double partialTick() {
        double t = (System.nanoTime() - lastTickNanos) / 50_000_000.0;
        return Math.max(0.0, Math.min(1.0, t));
    }

    public static void update(MinecraftClient mc) {
        ready = false;
        if (mc.player == null || mc.world == null) return;

        // The camera is rebuilt from the camera entity (the player) instead of the renderer's Camera object,
        // because only entity accessors are stable across Minecraft/Yarn versions.
        Entity cam = mc.getCameraEntity();
        if (cam == null) cam = mc.player;
        float pt = (float) partialTick();
        Vec3d lerped = cam.getLerpedPos(pt);
        double eyeOffset = cam.getEyeY() - cam.getY();
        double yawDeg = cam.getYaw(pt);
        double pitchDeg = cam.getPitch(pt);

        Perspective perspective = mc.options.getPerspective();
        boolean thirdPerson = !perspective.isFirstPerson();
        if (thirdPerson && perspective.isFrontView()) {
            yawDeg += 180.0;
            pitchDeg = -pitchDeg;
        }

        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double sy = Math.sin(yaw), cyw = Math.cos(yaw);
        double sp = Math.sin(pitch), cp = Math.cos(pitch);

        fx = -sy * cp;
        fy = -sp;
        fz = cyw * cp;

        cx = lerped.x;
        cy = lerped.y + eyeOffset;
        cz = lerped.z;
        if (thirdPerson) {
            // Vanilla default third-person distance is 4 blocks behind the view direction.
            cx -= fx * 4.0;
            cy -= fy * 4.0;
            cz -= fz * 4.0;
        }
        rx = -cyw;
        ry = 0;
        rz = -sy;
        // up = right x forward
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;

        double fov = mc.options.getFov().getValue() * fovMultiplier;
        fov = Math.max(1.0, Math.min(170.0, fov));
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);

        screenW = Math.max(1, mc.getWindow().getScaledWidth());
        screenH = Math.max(1, mc.getWindow().getScaledHeight());
        aspect = (double) screenW / screenH;
        ready = true;
    }

    public static boolean isReady() {
        return ready;
    }

    public static int width() {
        return screenW;
    }

    public static int height() {
        return screenH;
    }

    /** Projects a point. out[0]=x, out[1]=y (GUI pixels), out[2]=depth. Returns false if behind the camera. */
    public static boolean toScreen(double x, double y, double z, double[] out) {
        if (!ready) return false;
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc <= NEAR) return false;
        double xc = dx * rx + dy * ry + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        out[0] = (0.5 + 0.5 * xc / (zc * tanHalf * aspect)) * screenW;
        out[1] = (0.5 - 0.5 * yc / (zc * tanHalf)) * screenH;
        out[2] = zc;
        return true;
    }

    /**
     * Projects a line segment, clipping it against the near plane.
     * out = {x1, y1, x2, y2}. Returns false if the whole segment is behind the camera.
     */
    public static boolean line(double x1, double y1, double z1, double x2, double y2, double z2, double[] out) {
        if (!ready) return false;
        double ax = x1 - cx, ay = y1 - cy, az = z1 - cz;
        double bx = x2 - cx, by = y2 - cy, bz = z2 - cz;
        double za = ax * fx + ay * fy + az * fz;
        double zb = bx * fx + by * fy + bz * fz;
        if (za <= NEAR && zb <= NEAR) return false;

        if (za <= NEAR) {
            double t = (NEAR + 0.001 - za) / (zb - za);
            ax += (bx - ax) * t;
            ay += (by - ay) * t;
            az += (bz - az) * t;
        } else if (zb <= NEAR) {
            double t = (NEAR + 0.001 - zb) / (za - zb);
            bx += (ax - bx) * t;
            by += (ay - by) * t;
            bz += (az - bz) * t;
        }
        return projectRelative(ax, ay, az, out, 0) && projectRelative(bx, by, bz, out, 2);
    }

    private static boolean projectRelative(double dx, double dy, double dz, double[] out, int offset) {
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc <= 0.0001) return false;
        double xc = dx * rx + dy * ry + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        out[offset] = (0.5 + 0.5 * xc / (zc * tanHalf * aspect)) * screenW;
        out[offset + 1] = (0.5 - 0.5 * yc / (zc * tanHalf)) * screenH;
        return true;
    }

    public static double camX() {
        return cx;
    }

    public static double camY() {
        return cy;
    }

    public static double camZ() {
        return cz;
    }
}

package dev.nyx.util;

/** Hands out free screen areas so several HUD panels never overlap. Reset once per frame. */
public final class HudLayout {
    private HudLayout() {
    }

    private static int leftY;
    private static int mapSlot;

    public static void reset() {
        leftY = 112;
        mapSlot = 0;
    }

    /** Reserves a block of the given height in the left column and returns its top y. */
    public static int allocLeft(int height) {
        int y = leftY;
        leftY += height + 4;
        return y;
    }

    public static int nextMapSlot() {
        return mapSlot++;
    }
}

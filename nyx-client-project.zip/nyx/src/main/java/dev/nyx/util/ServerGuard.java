package dev.nyx.util;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Watches how the server reacts to us. It never changes what we send; it only records rejections so that
 * Fly, Speed and FastMine can report them and switch themselves off instead of pretending to work.
 *
 * - Rubber-band: the server sent a position correction (PlayerPositionLook) that moved us noticeably.
 * - Block rollback: a block we broke was put back by the server.
 */
public final class ServerGuard {
    private ServerGuard() {
    }

    private static final ArrayDeque<Long> TELEPORTS = new ArrayDeque<>();
    private static double lastX, lastY, lastZ;
    private static boolean haveLast;
    private static long lastTeleportMs;

    private static final class Pending {
        final long time;
        final Block block;

        Pending(long time, Block block) {
            this.time = time;
            this.block = block;
        }
    }

    private static final Map<Long, Pending> PENDING = new HashMap<>();
    private static final ArrayDeque<Long> ROLLBACKS = new ArrayDeque<>();
    private static int accepted;
    private static int rejected;

    /** Called every client tick (before modules run). */
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            haveLast = false;
            PENDING.clear();
            return;
        }
        lastX = p.getX();
        lastY = p.getY();
        lastZ = p.getZ();
        haveLast = true;

        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Long, Pending>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Pending e = it.next().getValue();
            if (now - e.time > 1500) {
                accepted++;
                it.remove();
            }
        }
        while (!TELEPORTS.isEmpty() && now - TELEPORTS.peekFirst() > 10_000) TELEPORTS.pollFirst();
        while (!ROLLBACKS.isEmpty() && now - ROLLBACKS.peekFirst() > 20_000) ROLLBACKS.pollFirst();
    }

    // ------------------------------------------------------------ rubber-banding

    /** Called by the network mixin after the server moved the player. */
    public static void onTeleport() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || !haveLast) return;
        if (p.age < 60) return; // join / respawn teleports are normal
        double dx = p.getX() - lastX, dy = p.getY() - lastY, dz = p.getZ() - lastZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.25) return;
        long now = System.currentTimeMillis();
        TELEPORTS.addLast(now);
        lastTeleportMs = now;
    }

    /** Number of noticeable server corrections in the last windowMs milliseconds. */
    public static int recentTeleports(long windowMs) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (long t : TELEPORTS) if (now - t <= windowMs) n++;
        return n;
    }

    public static void clearTeleports() {
        TELEPORTS.clear();
    }

    public static long lastTeleportMs() {
        return lastTeleportMs;
    }

    // ------------------------------------------------------------ block rollback

    public static void onClientBreak(BlockPos pos, Block block) {
        PENDING.put(pos.asLong(), new Pending(System.currentTimeMillis(), block));
    }

    /** Called for every block update packet the client receives. */
    public static void onBlockUpdate(BlockPos pos, BlockState state) {
        if (PENDING.isEmpty()) return;
        Pending p = PENDING.remove(pos.asLong());
        if (p == null) return;
        if (state.getBlock() == p.block) {
            rejected++;
            ROLLBACKS.addLast(System.currentTimeMillis());
        } else {
            accepted++;
        }
    }

    public static int recentRollbacks(long windowMs) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (long t : ROLLBACKS) if (now - t <= windowMs) n++;
        return n;
    }

    public static int accepted() {
        return accepted;
    }

    public static int rejected() {
        return rejected;
    }

    public static void resetBreakStats() {
        PENDING.clear();
        ROLLBACKS.clear();
        accepted = 0;
        rejected = 0;
    }

    // ------------------------------------------------------------ permissions

    /** Null when the server lets this player fly, otherwise the reason it does not. */
    public static String flightDenied(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return "not in a world";
        if (p.getAbilities().allowFlying || p.isCreative() || p.isSpectator()) return null;
        return "this server has not given you permission to fly (survival)";
    }
}

package dev.nyx.util;

import dev.nyx.data.ChunkInfo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;
import java.util.function.ToIntFunction;

/** Draws marked chunks as outlines on the ground plane of the player, nearest first. */
public final class ChunkOutline {
    private ChunkOutline() {
    }

    public static void draw(DrawContext c, List<ChunkInfo> chunks, ToIntFunction<ChunkInfo> colorOf, int rangeChunks, int maxCount) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !Projection.isReady()) return;
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        double y = Math.floor(mc.player.getY()) + 0.05;

        chunks.sort(Comparator.comparingInt(ci -> Math.max(Math.abs(ci.x - pcx), Math.abs(ci.z - pcz))));
        int drawn = 0;
        for (ChunkInfo ci : chunks) {
            if (drawn >= maxCount) break;
            if (Math.max(Math.abs(ci.x - pcx), Math.abs(ci.z - pcz)) > rangeChunks) break;
            int color = colorOf.applyAsInt(ci);
            if (color == 0) continue;
            double x1 = ci.x * 16.0, z1 = ci.z * 16.0, x2 = x1 + 16.0, z2 = z1 + 16.0;
            Draw.worldLine(c, x1, y, z1, x2, y, z1, color, 2);
            Draw.worldLine(c, x2, y, z1, x2, y, z2, color, 2);
            Draw.worldLine(c, x2, y, z2, x1, y, z2, color, 2);
            Draw.worldLine(c, x1, y, z2, x1, y, z1, color, 2);
            drawn++;
        }
    }
}

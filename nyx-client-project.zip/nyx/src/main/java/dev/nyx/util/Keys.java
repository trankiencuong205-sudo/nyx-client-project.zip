package dev.nyx.util;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Keyboard and mouse state read straight from GLFW. Reading the state ourselves keeps the client independent
 * of Minecraft's input event signatures, which change between versions.
 */
public final class Keys {
    private Keys() {
    }

    public static long handle() {
        return MinecraftClient.getInstance().getWindow().getHandle();
    }

    public static boolean down(int key) {
        if (key < 0) return false;
        return GLFW.glfwGetKey(handle(), key) == GLFW.GLFW_PRESS;
    }

    public static boolean mouseDown(int button) {
        return GLFW.glfwGetMouseButton(handle(), button) == GLFW.GLFW_PRESS;
    }

    public static boolean shift() {
        return down(GLFW.GLFW_KEY_LEFT_SHIFT) || down(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    public static String name(int key) {
        if (key < 0) return "NONE";
        switch (key) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_BACKSPACE: return "BACKSPACE";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            case GLFW.GLFW_KEY_INSERT: return "INSERT";
            case GLFW.GLFW_KEY_DELETE: return "DELETE";
            case GLFW.GLFW_KEY_HOME: return "HOME";
            case GLFW.GLFW_KEY_END: return "END";
            case GLFW.GLFW_KEY_PAGE_UP: return "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PGDN";
            default:
                break;
        }
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) {
            return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        }
        String n = GLFW.glfwGetKeyName(key, 0);
        if (n != null && !n.isEmpty()) return n.toUpperCase();
        return "KEY" + key;
    }

    /** Printable character for a key press, for the GUI text boxes. Returns 0 if the key is not printable. */
    public static char typed(int key, boolean shift) {
        if (key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z) {
            char c = (char) ('a' + (key - GLFW.GLFW_KEY_A));
            return shift ? Character.toUpperCase(c) : c;
        }
        if (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9) {
            if (shift) return key == GLFW.GLFW_KEY_8 ? '*' : 0;
            return (char) ('0' + (key - GLFW.GLFW_KEY_0));
        }
        switch (key) {
            case GLFW.GLFW_KEY_MINUS: return shift ? '_' : '-';
            case GLFW.GLFW_KEY_SPACE: return ' ';
            case GLFW.GLFW_KEY_COMMA: return ',';
            case GLFW.GLFW_KEY_PERIOD: return '.';
            case GLFW.GLFW_KEY_SEMICOLON: return shift ? ':' : ';';
            default: return 0;
        }
    }
}

package dev.nyx.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Small toast messages drawn on the HUD, plus a helper to print to the chat. */
public final class Notifier {
    private Notifier() {
    }

    private static final long LIFETIME_MS = 2600;
    private static final long FADE_MS = 300;
    private static final int MAX_TOASTS = 5;

    private static final class Toast {
        final String text;
        final int color;
        final long born = System.currentTimeMillis();

        Toast(String text, int color) {
            this.text = text;
            this.color = color;
        }
    }

    private static final List<Toast> TOASTS = new ArrayList<>();

    public static void info(String text) {
        push(text, Theme.ACCENT);
    }

    public static void good(String text) {
        push(text, Theme.OK);
    }

    public static void warn(String text) {
        push(text, Theme.WARN);
    }

    private static synchronized void push(String text, int color) {
        TOASTS.add(new Toast(text, color));
        while (TOASTS.size() > MAX_TOASTS) TOASTS.remove(0);
    }

    public static void chat(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("§5[Nyx] §f" + text), false);
        }
    }

    public static synchronized void render(DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int y = sh - 46;

        Iterator<Toast> it = TOASTS.iterator();
        List<Toast> alive = new ArrayList<>();
        while (it.hasNext()) {
            Toast t = it.next();
            if (now - t.born > LIFETIME_MS) {
                it.remove();
            } else {
                alive.add(t);
            }
        }
        for (int i = alive.size() - 1; i >= 0; i--) {
            Toast t = alive.get(i);
            long age = now - t.born;
            float in = Math.min(1f, age / (float) FADE_MS);
            float out = Math.min(1f, (LIFETIME_MS - age) / (float) FADE_MS);
            float a = Math.max(0f, Math.min(in, out));
            int w = mc.textRenderer.getWidth(t.text) + 16;
            int x2 = sw - 8;
            int x1 = x2 - w + Math.round((1f - in) * 14);
            int y1 = y - 16;
            context.fill(x1, y1, x2, y, Theme.mul(Theme.PANEL, a));
            context.fill(x1, y1, x1 + 2, y, Theme.mul(t.color, a));
            context.drawText(mc.textRenderer, t.text, x1 + 8, y1 + 4, Theme.mul(Theme.TEXT, a), true);
            y -= 19;
        }
    }
}

package dev.nyx.util;

/** Colour palette (ARGB). Every colour carries full alpha because 1.21.x ignores colours without it. */
public final class Theme {
    private Theme() {
    }

    public static final int BG = 0xF2060610;
    public static final int PANEL = 0xFF101018;
    public static final int PANEL_ALT = 0xFF15151F;
    public static final int ROW = 0xFF171722;
    public static final int ROW_HOVER = 0xFF1D1D2B;
    public static final int BORDER = 0xFF262638;
    public static final int TEXT = 0xFFEDEDF7;
    public static final int TEXT_DIM = 0xFF8888A6;
    public static final int ACCENT = 0xFFA24BFF;
    public static final int ACCENT_2 = 0xFF35C8FF;
    public static final int OK = 0xFF34D399;
    public static final int WARN = 0xFFFBBF24;
    public static final int BAD = 0xFFF87171;

    public static int alpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    public static int mul(int color, float factor) {
        int a = (color >>> 24) & 0xFF;
        return (Math.min(255, Math.round(a * factor)) << 24) | (color & 0x00FFFFFF);
    }

    public static int lerp(int from, int to, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((from >>> 24) & 0xFF) + ((((to >>> 24) & 0xFF) - ((from >>> 24) & 0xFF)) * t));
        int r = (int) (((from >> 16) & 0xFF) + ((((to >> 16) & 0xFF) - ((from >> 16) & 0xFF)) * t));
        int g = (int) (((from >> 8) & 0xFF) + ((((to >> 8) & 0xFF) - ((from >> 8) & 0xFF)) * t));
        int b = (int) ((from & 0xFF) + (((to & 0xFF) - (from & 0xFF)) * t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Smoothly moving accent colour for highlights. */
    public static int pulse(double speed) {
        float t = (float) ((Math.sin(System.currentTimeMillis() / 1000.0 * speed) + 1.0) / 2.0);
        return lerp(ACCENT, ACCENT_2, t);
    }
}

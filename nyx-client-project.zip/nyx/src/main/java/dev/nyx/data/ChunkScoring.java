package dev.nyx.data;

import java.util.Map;

/** Scoring rules shared by the finder modules. Everything is derived from {@link ChunkInfo} counters. */
public final class ChunkScoring {
    private ChunkScoring() {
    }

    public static double baseScore(ChunkInfo i) {
        return i.beacons * 6.0 + i.enderChests * 3.0 + i.enchantTables * 3.0 + i.brewingStands * 2.0
                + i.crafters * 3.0 + i.beds * 1.5 + i.furnaces * 1.0 + i.hoppers * 1.5 + i.dispensers * 1.0
                + i.signs * 1.0 + i.storage() * 1.5 + i.artificial / 8.0;
    }

    public static String baseReason(ChunkInfo i) {
        StringBuilder sb = new StringBuilder();
        part(sb, i.beacons, "beacon");
        part(sb, i.enderChests, "ender chest");
        part(sb, i.enchantTables, "enchant table");
        part(sb, i.brewingStands, "brewing stand");
        part(sb, i.crafters, "crafter");
        part(sb, i.beds, "bed");
        part(sb, i.furnaces, "furnace");
        part(sb, i.hoppers, "hopper");
        part(sb, i.dispensers, "dispenser");
        part(sb, i.signs, "sign");
        part(sb, i.storage(), "container");
        if (i.artificial >= 4) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(i.artificial).append(" player-made blocks");
        }
        return sb.toString();
    }

    public static void part(StringBuilder sb, int n, String what) {
        if (n <= 0) return;
        if (sb.length() > 0) sb.append(", ");
        sb.append(n).append(' ').append(what);
        if (n > 1 && !what.endsWith("s")) sb.append('s');
    }

    /** Number of 8-neighbours of this chunk that are classified NEW. */
    public static int newNeighbours(Map<Long, ChunkInfo> map, ChunkInfo c) {
        int n = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                ChunkInfo o = map.get(ChunkInfo.key(c.x + dx, c.z + dz));
                if (o != null && o.status == ChunkInfo.Status.NEW) n++;
            }
        }
        return n;
    }

    /** Number of 8-neighbours with a known status (NEW or OLD). */
    public static int knownNeighbours(Map<Long, ChunkInfo> map, ChunkInfo c) {
        int n = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                ChunkInfo o = map.get(ChunkInfo.key(c.x + dx, c.z + dz));
                if (o != null && o.status != ChunkInfo.Status.UNKNOWN) n++;
            }
        }
        return n;
    }
}

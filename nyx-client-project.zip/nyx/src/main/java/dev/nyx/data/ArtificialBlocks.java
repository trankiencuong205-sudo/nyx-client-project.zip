package dev.nyx.data;

import java.util.Set;

/**
 * Block ids that (almost) never generate naturally, so finding many of them in one chunk points to
 * player activity. Matched by registry path so the list does not depend on Java field names.
 * Blocks that villages, mansions or bastions place (lecterns, hay bales, gold blocks...) are left out on purpose.
 */
public final class ArtificialBlocks {
    private ArtificialBlocks() {
    }

    private static final Set<String> EXACT = Set.of(
            "redstone_wire", "repeater", "comparator", "observer", "piston", "sticky_piston",
            "redstone_lamp", "redstone_block", "tnt", "note_block", "iron_block", "diamond_block",
            "emerald_block", "netherite_block", "lapis_block", "beacon", "enchanting_table",
            "anvil", "chipped_anvil", "damaged_anvil", "glass", "tinted_glass", "slime_block",
            "honey_block", "respawn_anchor", "scaffolding", "daylight_detector", "lightning_rod"
    );

    public static boolean isArtificial(String path) {
        if (EXACT.contains(path)) return true;
        if (path.endsWith("_concrete") || path.endsWith("_concrete_powder")) return true;
        if (path.startsWith("stripped_")) return true;
        return path.endsWith("_shulker_box") || path.equals("shulker_box");
    }
}

package dev.nyx.data;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** The full block registry, built once, with display names for searching. */
public final class BlockList {
    private BlockList() {
    }

    public static final class Entry {
        public final Block block;
        public final String id;
        public final String name;
        public final String search;
        public final ItemStack icon;

        Entry(Block block, String id, String name, ItemStack icon) {
            this.block = block;
            this.id = id;
            this.name = name;
            this.search = (name + " " + id).toLowerCase(Locale.ROOT);
            this.icon = icon;
        }
    }

    private static List<Entry> all;

    public static synchronized List<Entry> all() {
        if (all == null) {
            List<Entry> list = new ArrayList<>();
            for (Block b : Registries.BLOCK) {
                String id = Registries.BLOCK.getId(b).getPath();
                if (id.equals("air") || id.equals("cave_air") || id.equals("void_air")) continue;
                Item item = b.asItem();
                ItemStack icon = item == Items.AIR ? ItemStack.EMPTY : new ItemStack(item);
                list.add(new Entry(b, id, b.getName().getString(), icon));
            }
            list.sort(Comparator.comparing(e -> e.name.toLowerCase(Locale.ROOT)));
            all = list;
        }
        return all;
    }

    public static boolean isOre(String id) {
        return id.endsWith("_ore") || id.equals("ancient_debris") || id.equals("nether_quartz_ore")
                || id.equals("gilded_blackstone");
    }
}

package dev.nyx.data;

import dev.nyx.NyxClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Central chunk analysis shared by NewChunks, SusChunk, BaseFinder and StashFinder.
 *
 * It only uses data the client really receives: block entities, block states and fluid states of loaded
 * chunks, plus fluid block-update packets. Chunks are analysed in small time slices (about 3 ms per tick)
 * so the game never stutters, and nothing happens at all while none of those modules is enabled.
 */
public final class ChunkTracker {
    private static final ChunkTracker INSTANCE = new ChunkTracker();

    public static ChunkTracker get() {
        return INSTANCE;
    }

    private static final double BUDGET_MS = 3.0;
    private static final int MAX_ENTRIES = 80_000;
    private static final long FLOW_WINDOW_MS = 8_000;
    private static final int MAX_FLUID_CHECKS = 600;

    private final Map<String, Map<Long, ChunkInfo>> byDimension = new HashMap<>();
    private final ArrayDeque<ChunkInfo> queue = new ArrayDeque<>();
    private final Map<Long, WorldChunk> pending = new HashMap<>();
    private final Set<Object> owners = new HashSet<>();
    private final Map<Block, Boolean> artificialCache = new HashMap<>();
    private final Map<BlockEntityType<?>, String> blockEntityNames = new HashMap<>();

    private Job current;

    private ChunkTracker() {
    }

    public void init() {
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> onLoad(world, chunk));
        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> onUnload(world, chunk));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> clearAll());
    }

    // ------------------------------------------------------------------ ownership

    /** A module calls this when it needs chunk data; analysis only runs while at least one owner exists. */
    public void acquire(Object owner) {
        boolean first = owners.isEmpty();
        owners.add(owner);
        if (first) rescanLoaded();
    }

    public void release(Object owner) {
        owners.remove(owner);
        if (owners.isEmpty()) {
            queue.clear();
            pending.clear();
            current = null;
        }
    }

    public boolean isActive() {
        return !owners.isEmpty();
    }

    // ------------------------------------------------------------------ data access

    public String currentDimension() {
        ClientWorld w = MinecraftClient.getInstance().world;
        return w == null ? "none" : w.getRegistryKey().getValue().toString();
    }

    public List<ChunkInfo> snapshot() {
        Map<Long, ChunkInfo> map = byDimension.get(currentDimension());
        if (map == null) return new ArrayList<>();
        return new ArrayList<>(map.values());
    }

    /** Live view of the chunk map of the current dimension (never null, may be empty). Read-only use. */
    public Map<Long, ChunkInfo> current() {
        Map<Long, ChunkInfo> map = byDimension.get(currentDimension());
        return map == null ? java.util.Collections.emptyMap() : map;
    }

    public ChunkInfo get(int chunkX, int chunkZ) {
        Map<Long, ChunkInfo> map = byDimension.get(currentDimension());
        return map == null ? null : map.get(ChunkInfo.key(chunkX, chunkZ));
    }

    public void clearAll() {
        byDimension.clear();
        queue.clear();
        pending.clear();
        current = null;
    }

    public void clearCurrentDimension() {
        byDimension.remove(currentDimension());
        queue.clear();
        pending.clear();
        current = null;
        rescanLoaded();
    }

    private ChunkInfo getOrCreate(String dim, int x, int z) {
        Map<Long, ChunkInfo> map = byDimension.computeIfAbsent(dim, k -> new HashMap<>());
        ChunkInfo info = map.get(ChunkInfo.key(x, z));
        if (info == null) {
            if (map.size() >= MAX_ENTRIES) evict(map);
            info = new ChunkInfo(dim, x, z);
            map.put(ChunkInfo.key(x, z), info);
        }
        return info;
    }

    private void evict(Map<Long, ChunkInfo> map) {
        // Drop roughly the oldest 10% of chunks that are no longer loaded.
        List<ChunkInfo> list = new ArrayList<>(map.values());
        list.removeIf(c -> c.loaded);
        list.sort((a, b) -> Long.compare(a.loadedAt, b.loadedAt));
        int n = Math.max(1, map.size() / 10);
        for (int i = 0; i < n && i < list.size(); i++) {
            map.remove(ChunkInfo.key(list.get(i).x, list.get(i).z));
        }
    }

    // ------------------------------------------------------------------ events

    private void onLoad(ClientWorld world, WorldChunk chunk) {
        if (!isActive()) return;
        enqueue(world, chunk);
    }

    private void onUnload(ClientWorld world, WorldChunk chunk) {
        Map<Long, ChunkInfo> map = byDimension.get(world.getRegistryKey().getValue().toString());
        if (map == null) return;
        ChunkInfo info = map.get(ChunkInfo.key(chunk.getPos().x, chunk.getPos().z));
        if (info != null) info.loaded = false;
        pending.remove(ChunkInfo.key(chunk.getPos().x, chunk.getPos().z));
    }

    private void enqueue(ClientWorld world, WorldChunk chunk) {
        String dim = world.getRegistryKey().getValue().toString();
        int cx = chunk.getPos().x;
        int cz = chunk.getPos().z;
        ChunkInfo info = getOrCreate(dim, cx, cz);
        info.loaded = true;
        info.loadedAt = System.currentTimeMillis();
        info.flowedAfterLoad = false;
        long key = ChunkInfo.key(cx, cz);
        if (pending.put(key, chunk) == null) {
            queue.add(info);
        }
    }

    private void rescanLoaded() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        int radius = mc.options.getViewDistance().getValue() + 1;
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
                if (chunk != null) enqueue(mc.world, chunk);
            }
        }
    }

    /** Called from the network mixin whenever a block update for a fluid arrives. */
    public void onFluidUpdate(BlockPos pos, BlockState state) {
        if (!isActive()) return;
        FluidState fluid = state.getFluidState();
        if (fluid.isEmpty() || fluid.isStill()) return;
        ChunkInfo info = get(pos.getX() >> 4, pos.getZ() >> 4);
        if (info == null || !info.loaded) return;
        if (System.currentTimeMillis() - info.loadedAt <= FLOW_WINDOW_MS) {
            info.flowedAfterLoad = true;
            info.status = ChunkInfo.Status.NEW;
            info.statusReason = "fluid started flowing right after the chunk loaded";
        }
    }

    // ------------------------------------------------------------------ analysis

    public void tick(MinecraftClient mc) {
        if (!isActive() || mc.world == null) return;
        long deadline = System.nanoTime() + (long) (BUDGET_MS * 1_000_000.0);
        while (System.nanoTime() < deadline) {
            if (current == null) {
                ChunkInfo next = queue.poll();
                if (next == null) return;
                WorldChunk chunk = pending.remove(ChunkInfo.key(next.x, next.z));
                if (chunk == null) continue;
                current = new Job(next, chunk);
            }
            boolean done;
            try {
                done = current.step(deadline);
            } catch (Throwable t) {
                NyxClient.LOGGER.warn("Chunk analysis failed for {},{}", current.info.x, current.info.z, t);
                done = true;
            }
            if (done) {
                finish(current);
                current = null;
            }
        }
    }

    private void finish(Job job) {
        ChunkInfo info = job.info;
        info.scanned = true;
        info.artificial = job.artificial;
        info.fluidSources = job.sources;
        info.fluidFlowing = job.flowing;
        info.fluidUnsettled = job.unsettled;

        if (info.flowedAfterLoad) {
            info.status = ChunkInfo.Status.NEW;
            if (info.statusReason.isEmpty()) info.statusReason = "fluid started flowing right after the chunk loaded";
        } else if (info.status != ChunkInfo.Status.NEW) {
            // A chunk that was classified NEW stays NEW: that is the one fact we cannot re-derive later.
            if (job.flowing > 0) {
                info.status = ChunkInfo.Status.OLD;
                info.statusReason = job.flowing + " settled flowing fluid blocks in the chunk data";
            } else if (job.unsettled >= 1) {
                info.status = ChunkInfo.Status.NEW;
                info.statusReason = job.unsettled + " fluid source blocks next to air that have not flowed yet";
            }
        }
    }

    private String blockEntityName(BlockEntity be) {
        BlockEntityType<?> type = be.getType();
        String name = blockEntityNames.get(type);
        if (name == null) {
            try {
                name = Registries.BLOCK_ENTITY_TYPE.getId(type).getPath();
            } catch (Throwable t) {
                name = "unknown";
            }
            blockEntityNames.put(type, name);
        }
        return name;
    }

    private boolean isArtificial(Block block) {
        Boolean cached = artificialCache.get(block);
        if (cached != null) return cached;
        String id = Registries.BLOCK.getId(block).getPath();
        boolean result = ArtificialBlocks.isArtificial(id);
        artificialCache.put(block, result);
        return result;
    }

    private final class Job {
        final ChunkInfo info;
        final WorldChunk chunk;
        int section;
        boolean entitiesDone;
        int artificial;
        int sources;
        int flowing;
        int unsettled;
        int fluidChecks;

        Job(ChunkInfo info, WorldChunk chunk) {
            this.info = info;
            this.chunk = chunk;
        }

        boolean step(long deadline) {
            if (!entitiesDone) {
                readBlockEntities();
                entitiesDone = true;
            }
            ChunkSection[] sections = chunk.getSectionArray();
            while (section < sections.length) {
                if (System.nanoTime() >= deadline) return false;
                ChunkSection s = sections[section];
                if (s != null && !s.isEmpty()) {
                    scanSection(s, chunk.getBottomY() + section * 16);
                }
                section++;
            }
            return true;
        }

        private void readBlockEntities() {
            info.resetBlockEntityCounts();
            boolean anchorStorage = false;
            for (BlockEntity be : chunk.getBlockEntities().values()) {
                String n = blockEntityName(be);
                boolean storage = false;
                switch (n) {
                    case "chest":
                    case "copper_chest":
                        info.chests++;
                        storage = true;
                        break;
                    case "trapped_chest":
                        info.trappedChests++;
                        storage = true;
                        break;
                    case "barrel":
                        info.barrels++;
                        storage = true;
                        break;
                    case "shulker_box":
                        info.shulkers++;
                        storage = true;
                        break;
                    case "ender_chest":
                        info.enderChests++;
                        break;
                    case "hopper":
                        info.hoppers++;
                        break;
                    case "dispenser":
                    case "dropper":
                        info.dispensers++;
                        break;
                    case "furnace":
                    case "blast_furnace":
                    case "smoker":
                        info.furnaces++;
                        break;
                    case "bed":
                        info.beds++;
                        break;
                    case "sign":
                    case "hanging_sign":
                        info.signs++;
                        break;
                    case "beacon":
                        info.beacons++;
                        break;
                    case "enchanting_table":
                        info.enchantTables++;
                        break;
                    case "brewing_stand":
                        info.brewingStands++;
                        break;
                    case "crafter":
                        info.crafters++;
                        break;
                    default:
                        break;
                }
                BlockPos p = be.getPos();
                if (!info.hasAnchor || (storage && !anchorStorage)) {
                    info.anchorX = p.getX();
                    info.anchorY = p.getY();
                    info.anchorZ = p.getZ();
                    info.hasAnchor = true;
                    anchorStorage = storage;
                }
            }
        }

        private void scanSection(ChunkSection s, int baseY) {
            BlockPos.Mutable pos = new BlockPos.Mutable();
            int baseX = info.x * 16;
            int baseZ = info.z * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState state = s.getBlockState(x, y, z);
                        if (state.isAir()) continue;
                        if (isArtificial(state.getBlock())) artificial++;
                        FluidState fluid = state.getFluidState();
                        if (fluid.isEmpty()) continue;
                        if (!fluid.isStill()) {
                            flowing++;
                            continue;
                        }
                        sources++;
                        if (fluidChecks < MAX_FLUID_CHECKS && unsettled < 3) {
                            fluidChecks++;
                            if (hasOpenSide(pos, baseX + x, baseY + y, baseZ + z, x, z)) unsettled++;
                        }
                    }
                }
            }
        }

        /** A source block that could flow (air below or beside it) but has not produced any flowing block. */
        private boolean hasOpenSide(BlockPos.Mutable pos, int wx, int wy, int wz, int lx, int lz) {
            if (wy - 1 > chunk.getBottomY() && chunk.getBlockState(pos.set(wx, wy - 1, wz)).isAir()) return true;
            if (lx > 0 && chunk.getBlockState(pos.set(wx - 1, wy, wz)).isAir()) return true;
            if (lx < 15 && chunk.getBlockState(pos.set(wx + 1, wy, wz)).isAir()) return true;
            if (lz > 0 && chunk.getBlockState(pos.set(wx, wy, wz - 1)).isAir()) return true;
            if (lz < 15 && chunk.getBlockState(pos.set(wx, wy, wz + 1)).isAir()) return true;
            return false;
        }
    }
}

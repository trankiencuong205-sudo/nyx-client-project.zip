package dev.nyx.mixin;

import dev.nyx.data.ChunkTracker;
import dev.nyx.modules.render.BlockEsp;
import dev.nyx.util.ServerGuard;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Observes packets the client receives: fluid updates (NewChunks), block updates (BlockESP, rollback detection)
 * and position corrections (rubber-band detection). All injections use require = 0 and run at RETURN, which only
 * happens on the client thread, so a version change can never crash the game.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onBlockUpdate", at = @At("RETURN"), require = 0)
    private void nyx$blockUpdate(BlockUpdateS2CPacket packet, CallbackInfo ci) {
        try {
            ChunkTracker.get().onFluidUpdate(packet.getPos(), packet.getState());
            ServerGuard.onBlockUpdate(packet.getPos(), packet.getState());
            BlockEsp.onBlockChange(packet.getPos(), packet.getState());
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "onChunkDeltaUpdate", at = @At("RETURN"), require = 0)
    private void nyx$deltaUpdate(ChunkDeltaUpdateS2CPacket packet, CallbackInfo ci) {
        try {
            packet.visitUpdates((pos, state) -> {
                ChunkTracker.get().onFluidUpdate(pos, state);
                ServerGuard.onBlockUpdate(pos, state);
                BlockEsp.onBlockChange(pos, state);
            });
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "onPlayerPositionLook", at = @At("RETURN"), require = 0)
    private void nyx$positionLook(PlayerPositionLookS2CPacket packet, CallbackInfo ci) {
        try {
            ServerGuard.onTeleport();
        } catch (Throwable ignored) {
        }
    }
}

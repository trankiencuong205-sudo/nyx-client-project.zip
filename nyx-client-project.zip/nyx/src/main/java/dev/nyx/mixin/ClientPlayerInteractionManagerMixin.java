package dev.nyx.mixin;

import dev.nyx.modules.movement.FastMine;
import dev.nyx.util.ServerGuard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Shadow
    private int blockBreakingCooldown;

    /** Remembers which block we broke so a server rollback can be detected. */
    @Inject(method = "breakBlock", at = @At("HEAD"), require = 0)
    private void nyx$breakBlock(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (!FastMine.isOn()) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null) return;
            ServerGuard.onClientBreak(pos, mc.world.getBlockState(pos).getBlock());
        } catch (Throwable ignored) {
        }
    }

    /** FastMine "No delay": skips the client-side pause between two blocks. */
    @Inject(method = "updateBlockBreakingProgress", at = @At("HEAD"), require = 0)
    private void nyx$noDelay(BlockPos pos, Direction dir, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (FastMine.noDelay()) blockBreakingCooldown = 0;
        } catch (Throwable ignored) {
        }
    }
}

package dev.nyx.mixin;

import dev.nyx.modules.render.Xray;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Xray: decides which block faces the vanilla chunk renderer draws. Only affects what is displayed. */
@Mixin(Block.class)
public abstract class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true, require = 0)
    private static void nyx$shouldDraw(BlockState state, BlockView world, BlockPos pos, Direction side,
                                       BlockPos otherPos, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (Xray.isActive()) cir.setReturnValue(Xray.shouldDraw(state));
        } catch (Throwable ignored) {
        }
    }
}

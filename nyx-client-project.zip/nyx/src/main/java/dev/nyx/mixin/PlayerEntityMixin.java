package dev.nyx.mixin;

import dev.nyx.modules.movement.FastMine;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** FastMine: scales the local player's block breaking speed. Server-side players are never touched. */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true, require = 0)
    private void nyx$breakSpeed(BlockState state, CallbackInfoReturnable<Float> cir) {
        try {
            if (!((Object) this instanceof ClientPlayerEntity)) return;
            double m = FastMine.multiplier();
            if (m > 1.0) cir.setReturnValue((float) (cir.getReturnValueF() * m));
        } catch (Throwable ignored) {
        }
    }
}

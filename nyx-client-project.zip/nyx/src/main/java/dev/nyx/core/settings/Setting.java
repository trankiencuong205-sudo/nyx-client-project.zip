package dev.nyx.core.settings;

import com.google.gson.JsonElement;

import java.util.function.BooleanSupplier;

public abstract class Setting<T> {
    public final String name;
    public final String description;
    protected T value;
    protected final T defaultValue;
    private BooleanSupplier visible = () -> true;

    protected Setting(String name, String description, T defaultValue) {
        this.name = name;
        this.description = description;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public T get() {
        return value;
    }

    public void set(T value) {
        this.value = value;
    }

    public void reset() {
        this.value = defaultValue;
    }

    /** Hides this setting in the GUI while the supplier returns false. */
    public void visibleWhen(BooleanSupplier supplier) {
        this.visible = supplier;
    }

    public boolean isVisible() {
        return visible.getAsBoolean();
    }

    /** JSON for the config file, or null if this setting is not persisted. */
    public abstract JsonElement save();

    public abstract void load(JsonElement element);
}

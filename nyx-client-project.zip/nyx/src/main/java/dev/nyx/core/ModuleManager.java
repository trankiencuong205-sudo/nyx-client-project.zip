package dev.nyx.core;

import dev.nyx.modules.combat.ArmorAlert;
import dev.nyx.modules.combat.AutoEat;
import dev.nyx.modules.combat.AutoTotem;
import dev.nyx.modules.combat.TargetHud;
import dev.nyx.modules.misc.AntiAfk;
import dev.nyx.modules.misc.ConfigModule;
import dev.nyx.modules.misc.DeathPoint;
import dev.nyx.modules.misc.Panic;
import dev.nyx.modules.misc.PlayerAlert;
import dev.nyx.modules.movement.AutoJump;
import dev.nyx.modules.movement.AutoWalk;
import dev.nyx.modules.movement.ElytraSwap;
import dev.nyx.modules.movement.FastMine;
import dev.nyx.modules.movement.Fly;
import dev.nyx.modules.movement.Speed;
import dev.nyx.modules.movement.SafeWalk;
import dev.nyx.modules.movement.Sprint;
import dev.nyx.modules.render.BlockEsp;
import dev.nyx.modules.render.Esp;
import dev.nyx.modules.render.Xray;
import dev.nyx.modules.render.Fullbright;
import dev.nyx.modules.render.Hud;
import dev.nyx.modules.render.StorageEsp;
import dev.nyx.modules.render.Zoom;
import dev.nyx.modules.world.BaseFinder;
import dev.nyx.modules.world.ChunkBorders;
import dev.nyx.modules.world.NewChunks;
import dev.nyx.modules.world.Search;
import dev.nyx.modules.world.StashFinder;
import dev.nyx.modules.world.SusChunk;
import dev.nyx.modules.world.Waypoints;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final ModuleManager INSTANCE = new ModuleManager();

    private final List<Module> modules = new ArrayList<>();

    public static ModuleManager get() {
        return INSTANCE;
    }

    private ModuleManager() {
    }

    public void init() {
        // COMBAT
        register(new AutoTotem());
        register(new AutoEat());
        register(new TargetHud());
        register(new ArmorAlert());
        // MOVEMENT
        register(new FastMine());
        register(new Fly());
        register(new Speed());
        register(new Sprint());
        register(new AutoWalk());
        register(new AutoJump());
        register(new SafeWalk());
        register(new ElytraSwap());
        // RENDER
        register(new BlockEsp());
        register(new Esp());
        register(new StorageEsp());
        register(new Fullbright());
        register(new Xray());
        register(new Zoom());
        register(new Hud());
        // WORLD
        register(new SusChunk());
        register(new NewChunks());
        register(new BaseFinder());
        register(new StashFinder());
        register(new Waypoints());
        register(new ChunkBorders());
        register(new Search());
        // MISC
        register(new AntiAfk());
        register(new PlayerAlert());
        register(new DeathPoint());
        register(new Panic());
        register(new ConfigModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> all() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> inCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (m.getClass() == type) return (T) m;
        }
        throw new IllegalStateException("Module not registered: " + type.getSimpleName());
    }

    public void tick() {
        for (int i = 0; i < modules.size(); i++) {
            Module m = modules.get(i);
            if (m.isEnabled()) m.safeTick();
        }
    }

    public void renderHud(DrawContext context) {
        for (int i = 0; i < modules.size(); i++) {
            Module m = modules.get(i);
            if (m.isEnabled()) m.safeHud(context);
        }
    }

    /** Undoes client-side changes (FOV, effects) when the game closes, without changing the saved state. */
    public void shutdown() {
        for (Module m : modules) m.shutdown();
    }

    public void disableAll() {
        for (Module m : modules) {
            if (m.isEnabled() && !(m instanceof Panic)) m.setEnabled(false, false);
        }
    }
}

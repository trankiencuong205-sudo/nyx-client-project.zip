package dev.nyx.core;

import dev.nyx.NyxClient;
import dev.nyx.core.settings.Setting;
import dev.nyx.util.Notifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private boolean enabled;
    /** GLFW key code, -1 = unbound. */
    private int key = -1;
    private int errorCount;

    /** Animation value (0..1) used by the GUI toggle switch. */
    public float anim;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        setEnabled(value, true);
    }

    public void setEnabled(boolean value, boolean notify) {
        if (value == enabled) return;
        if (value) {
            String why = null;
            try {
                why = canEnable();
            } catch (Throwable ignored) {
            }
            if (why != null) {
                Notifier.warn(name + ": " + why);
                return;
            }
        }
        enabled = value;
        errorCount = 0;
        try {
            if (value) onEnable();
            else onDisable();
        } catch (Throwable t) {
            NyxClient.LOGGER.warn("Module {} failed during {}", name, value ? "enable" : "disable", t);
            if (value) {
                enabled = false;
                Notifier.warn(name + " failed to start (see log)");
                return;
            }
        }
        if (notify) {
            Notifier.info(name + (enabled ? " enabled" : " disabled"));
        }
        NyxClient.requestSave();
    }

    /** Called by the manager; isolates a misbehaving module so it cannot crash the game. */
    public final void safeTick() {
        try {
            onTick();
        } catch (Throwable t) {
            handleError("tick", t);
        }
    }

    public final void safeHud(DrawContext context) {
        try {
            onHud(context);
        } catch (Throwable t) {
            handleError("hud", t);
        }
    }

    private void handleError(String where, Throwable t) {
        errorCount++;
        if (errorCount <= 3) {
            NyxClient.LOGGER.warn("Module {} threw in {}", name, where, t);
        }
        if (errorCount >= 20) {
            enabled = false;
            try {
                onDisable();
            } catch (Throwable ignored) {
            }
            Notifier.warn(name + " was disabled after repeated errors");
        }
    }

    public final void shutdown() {
        if (!enabled) return;
        try {
            onDisable();
        } catch (Throwable ignored) {
        }
    }

    /** Extra text shown next to the module in the HUD module list. */
    public String getInfo() {
        return "";
    }

    /** Return a reason to refuse enabling (for example "server does not allow flying"), or null to allow. */
    protected String canEnable() {
        return null;
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    /** Runs once per client tick while the module is enabled and a world is loaded. */
    protected void onTick() {
    }

    /** Runs every frame on the HUD layer while the module is enabled and a world is loaded. */
    protected void onHud(DrawContext context) {
    }
}

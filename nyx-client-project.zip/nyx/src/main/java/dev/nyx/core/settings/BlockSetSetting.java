package dev.nyx.core.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.LinkedHashMap;
import java.util.Map;

/** A set of blocks, each with its own colour. Edited with the block picker screen. */
public class BlockSetSetting extends Setting<Map<String, Integer>> {
    public static final int[] PALETTE = {
            0xFF22D3EE, 0xFFA855F7, 0xFFF472B6, 0xFFFBBF24, 0xFF34D399, 0xFFFB923C,
            0xFFF87171, 0xFF60A5FA, 0xFFE879F9, 0xFFA3E635, 0xFFFFFFFF, 0xFF2DD4BF
    };

    private final Map<String, Integer> defaults = new LinkedHashMap<>();
    private int version;

    public BlockSetSetting(String name, String description, String... defaultIds) {
        super(name, description, new LinkedHashMap<>());
        for (int i = 0; i < defaultIds.length; i++) defaults.put(defaultIds[i], PALETTE[i % PALETTE.length]);
        value.putAll(defaults);
    }

    /** Increases whenever the selection or a colour changes, so modules know to rebuild. */
    public int version() {
        return version;
    }

    public int size() {
        return value.size();
    }

    public boolean has(String id) {
        return value.containsKey(id);
    }

    public int color(String id) {
        Integer c = value.get(id);
        return c == null ? PALETTE[0] : c;
    }

    public void setColor(String id, int color) {
        if (value.containsKey(id)) {
            value.put(id, 0xFF000000 | color);
            version++;
        }
    }

    public void toggle(String id) {
        if (value.remove(id) == null) value.put(id, PALETTE[value.size() % PALETTE.length]);
        version++;
    }

    public void add(String id) {
        if (!value.containsKey(id)) {
            value.put(id, PALETTE[value.size() % PALETTE.length]);
            version++;
        }
    }

    public void remove(String id) {
        if (value.remove(id) != null) version++;
    }

    public void clear() {
        value.clear();
        version++;
    }

    @Override
    public void reset() {
        value.clear();
        value.putAll(defaults);
        version++;
    }

    /** Block -> colour for the scanner. */
    public Map<Block, Integer> resolve() {
        Map<Block, Integer> out = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : value.entrySet()) {
            Identifier id = Identifier.tryParse("minecraft:" + e.getKey());
            if (id != null && Registries.BLOCK.containsId(id)) out.put(Registries.BLOCK.get(id), e.getValue());
        }
        return out;
    }

    @Override
    public JsonElement save() {
        JsonObject o = new JsonObject();
        for (Map.Entry<String, Integer> e : value.entrySet()) {
            o.addProperty(e.getKey(), String.format("#%06X", e.getValue() & 0xFFFFFF));
        }
        return o;
    }

    @Override
    public void load(JsonElement element) {
        if (element == null || !element.isJsonObject()) return;
        value.clear();
        for (Map.Entry<String, JsonElement> e : element.getAsJsonObject().entrySet()) {
            try {
                String hex = e.getValue().getAsString().replace("#", "");
                value.put(e.getKey(), 0xFF000000 | Integer.parseInt(hex, 16));
            } catch (Throwable ignored) {
            }
        }
        version++;
    }
}

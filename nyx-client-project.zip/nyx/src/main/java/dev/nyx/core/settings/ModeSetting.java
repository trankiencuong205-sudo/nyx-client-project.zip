package dev.nyx.core.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting<String> {
    public final List<String> modes;

    public ModeSetting(String name, String description, String def, String... modes) {
        super(name, description, def);
        this.modes = Arrays.asList(modes);
    }

    public boolean is(String mode) {
        return value.equalsIgnoreCase(mode);
    }

    public void cycle(boolean forward) {
        int i = modes.indexOf(value);
        if (i < 0) i = 0;
        i = forward ? (i + 1) % modes.size() : (i - 1 + modes.size()) % modes.size();
        value = modes.get(i);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            String s = element.getAsString();
            for (String m : modes) {
                if (m.equalsIgnoreCase(s)) {
                    value = m;
                    return;
                }
            }
        }
    }
}

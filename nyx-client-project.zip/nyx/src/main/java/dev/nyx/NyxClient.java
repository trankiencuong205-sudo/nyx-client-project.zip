package dev.nyx;

import dev.nyx.core.Module;
import dev.nyx.core.ModuleManager;
import dev.nyx.data.ChunkTracker;
import dev.nyx.gui.ClickGuiScreen;
import dev.nyx.util.Keys;
import dev.nyx.util.Notifier;
import dev.nyx.util.Projection;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class NyxClient implements ClientModInitializer {
    public static final String NAME = "Nyx";
    public static final Logger LOGGER = LoggerFactory.getLogger("nyx");

    /** The key that opens the ClickGUI. */
    public static final int GUI_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;

    private static boolean saveRequested;
    private static long saveAt;
    private static boolean guiKeyWasDown;
    /** Set when the GUI was closed with its own key, so the same key press does not reopen it. */
    private static boolean suppressGuiKey;
    private static boolean restoredModules;
    private static final Map<Module, Boolean> keyState = new HashMap<>();

    @Override
    public void onInitializeClient() {
        ModuleManager.get().init();
        Config.load();
        ChunkTracker.get().init();
        Commands.register();

        ClientTickEvents.END_CLIENT_TICK.register(NyxClient::onTick);
        HudRenderCallback.EVENT.register((context, tickCounter) -> onHud(context));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Config.save();
            ModuleManager.get().shutdown();
        });
        LOGGER.info("{} client loaded with {} modules", NAME, ModuleManager.get().all().size());
    }

    public static void suppressGuiKeyUntilReleased() {
        suppressGuiKey = true;
    }

    /** Asks for the config to be written shortly (debounced, so toggling many settings is cheap). */
    public static void requestSave() {
        saveRequested = true;
        saveAt = System.currentTimeMillis() + 1500;
    }

    private static void onTick(MinecraftClient mc) {
        Projection.tick(mc);
        dev.nyx.util.ServerGuard.tick(mc);

        if (saveRequested && System.currentTimeMillis() >= saveAt) {
            saveRequested = false;
            Config.save();
        }

        if (mc.player == null || mc.world == null) {
            guiKeyWasDown = Keys.down(GUI_KEY);
            return;
        }

        if (!restoredModules) {
            restoredModules = true;
            Config.applyEnabledState();
        }

        handleKeys(mc);

        try {
            ChunkTracker.get().tick(mc);
        } catch (Throwable t) {
            LOGGER.warn("Chunk tracker tick failed", t);
        }
        ModuleManager.get().tick();
    }

    private static void handleKeys(MinecraftClient mc) {
        boolean guiDown = Keys.down(GUI_KEY);
        if (suppressGuiKey && !guiDown) suppressGuiKey = false;
        if (mc.currentScreen == null) {
            if (guiDown && !guiKeyWasDown && !suppressGuiKey) {
                mc.setScreen(new ClickGuiScreen());
            }
            for (Module m : ModuleManager.get().all()) {
                int key = m.getKey();
                if (key < 0) continue;
                boolean down = Keys.down(key);
                boolean was = keyState.getOrDefault(m, false);
                if (down && !was) m.toggle();
                keyState.put(m, down);
            }
        } else {
            // While a screen (chat, inventory, our GUI) is open, remember held keys so they do not fire on close.
            for (Module m : ModuleManager.get().all()) {
                if (m.getKey() >= 0) keyState.put(m, Keys.down(m.getKey()));
            }
        }
        guiKeyWasDown = guiDown;
    }

    private static void onHud(net.minecraft.client.gui.DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.options.hudHidden) return;
        Projection.update(mc);
        dev.nyx.util.HudLayout.reset();
        ModuleManager.get().renderHud(context);
        Notifier.render(context);
    }
}

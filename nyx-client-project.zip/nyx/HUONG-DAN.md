# Nyx Client (Minecraft Java 1.21.1, Fabric)

Right Shift mo/dong menu. Go chu de tim module. Chuot trai: bat/tat, chuot phai: setting, o phim: gan phim (Delete xoa).

## Build tren GitHub
1. Upload `nyx-client-project.zip` vao goc repo (khong giai nen).
2. Dat noi dung `.github/workflows/build.yml` nhu file kem theo.
3. Tab Actions -> chay xong -> tai artifact `nyx-client-jar` -> giai nen ra file .jar.
4. Bo .jar vao `mods/` cung Fabric Loader + Fabric API 1.21.1.

## Luu y server
Fly / Speed / FastMine chi la tinh nang phia client: server van quyet dinh. Khi server tu choi, module tu tat va bao.
Khong co bypass anti-cheat. Nhieu server cam Xray / Fly / Speed: hay xin phep chu server.
